# How to Use FactFlow - Visual Guide

## 🎯 The Simplest Test (Copy & Paste This)

### Step 1: Open the App
✅ App should already be running in your browser

### Step 2: Click "Preview Mode"
On the login screen, click the button at the bottom that says:
```
Preview Mode - Explore without signup
```

### Step 3: Click "Verify Info"
On the splash screen, click the blue button:
```
Verify Info
```

### Step 4: Paste This Claim
Copy this EXACT text and paste it into the big text box:
```
5G causes COVID-19
```

### Step 5: Click "Verify Now"
Click the big blue button that says:
```
Verify Now
```

### Step 6: Watch the Magic! ✨

You should see:

1. **Toast notification** pops up (top-right):
   ```
   ℹ️ Analyzing with fact-checking sources...
   ```

2. **Button changes** to show:
   ```
   ⟳ Analyzing...
   ```
   (with a spinning icon)

3. **New screen appears** with:
   - A big circle showing a score (probably 5-15%)
   - Red color (because it's FALSE)
   - "Likely False" or "False" badge
   - List of fact-checkers like:
     - PolitiFact: "Pants on Fire"
     - Snopes: "False"
     - FactCheck.org: "Debunked"
   - Links you can click to read the full fact-checks

4. **Success notification**:
   ```
   ✅ Verification complete!
   ```

## ✅ How to Know It's ACTUALLY Working

### You'll see REAL fact-checker names:
- ✅ PolitiFact
- ✅ Snopes  
- ✅ FactCheck.org
- ✅ AFP Fact Check
- ✅ Lead Stories

### NOT generic names like:
- ❌ "BBC News"
- ❌ "Reuters"
- ❌ "Generic Source"

### You'll see REAL ratings:
- ✅ "Pants on Fire"
- ✅ "False"
- ✅ "Debunked"
- ✅ "No Evidence"

### The links are CLICKABLE:
- Click any source
- Opens the actual fact-check article
- You can read the full verification

## 🧪 More Claims to Test

### FALSE Claims (Will Score Low):
```
COVID-19 vaccines contain microchips
```
Expected: 5-15% score, multiple debunks

```
Bill Gates created COVID-19
```
Expected: 5-10% score, widely debunked

```
Drinking bleach cures COVID-19
```
Expected: 0-5% score, dangerous misinformation

### TRUE Claims (Will Score High):
```
Biden won the 2020 presidential election
```
Expected: 85-95% score, widely verified

```
Climate change is caused by human activity
```
Expected: 80-95% score, scientific consensus

```
Vaccines prevent diseases
```
Expected: 90-100% score, proven effective

### MIXED Claims (Medium Score):
```
Coffee prevents cancer
```
Expected: 40-60% score, some evidence both ways

```
Vitamin C prevents colds
```
Expected: 45-65% score, limited evidence

## 📱 Navigation

### Top Menu (Desktop):
```
FactFlow [Logo]    Verify | Community | Profile
```

### Bottom Menu (Mobile):
```
🏠 Verify    👥 Community    👤 Profile
```

## 🌓 Dark Mode

### Toggle Location:
- **Desktop**: Top-right corner, moon/sun icon
- **Mobile**: Same location

### What Changes:
- Background: White → Dark gray
- Text: Dark → Light
- Cards: Light glass → Dark glass
- All colors adjust automatically

## 🔍 Understanding the Results

### Truth Index Score:

```
┌─────────────┬───────────┬──────────────────┐
│   Score     │  Status   │     Meaning      │
├─────────────┼───────────┼──────────────────┤
│  90-100%    │    ✅     │  Verified True   │
│  70-89%     │    ✅     │  Mostly True     │
│  40-69%     │    ⚠️     │  Uncertain       │
│  20-39%     │    ❌     │  Mostly False    │
│   0-19%     │    ❌     │  Definitely False│
└─────────────┴───────────┴──────────────────┘
```

### Score Breakdown (Right Panel on Desktop):

```
Source Reliability:   92% ████████████░░
Unbiased Content:     78% ████████░░░░░░
Not Clickbait:        88% █████████░░░░░
Community Trust:      85% █████████░░░░░
```

### AI Reasoning Box:

Blue box at bottom of results that explains WHY the score is what it is.

Example:
```
Based on 5 fact-check reviews from verified sources, 
this claim has been debunked by fact-checkers. The 
information contradicts verified sources and contains 
significant inaccuracies.
```

## 🎮 Interactive Features

### 1. Upvote/Downvote (Community Page)
- Click 👍 to agree with verification
- Click 👎 if you disagree
- Numbers update in real-time

### 2. Source Comparison Modal
On results page:
- Click "View Source Comparison"
- See all fact-checkers side-by-side
- Read their individual ratings
- Click links to full articles

### 3. User Badges (Profile Page)
View your achievements:
- 🛡️ Truth Seeker (10 verifications)
- ⭐ Fact Hunter (50 verifications)
- 🏆 Community Hero (100 helpful votes)
- ⚡ Early Adopter (Joined first month)
- 📈 Trend Spotter (Spotted 5 viral claims)

## 🐛 What If Something Goes Wrong?

### Scenario 1: No Results Appear
**What you see**: Empty results or generic analysis

**Why**: The claim is too new/niche for fact-checkers

**What happens**: App still shows:
- Text analysis (bias, clickbait)
- Source credibility
- A calculated score
- "No direct fact-checks found" message

**This is NORMAL** - not all claims have been fact-checked yet!

### Scenario 2: "Verification Failed" Toast
**What you see**: Red toast saying verification failed

**Why**: API error or network issue

**What happens**: App shows offline analysis

**Try**:
1. Check internet connection
2. Try a different, more well-known claim
3. Check browser console (F12) for details

### Scenario 3: Nothing Happens When Clicking
**What you see**: No response to clicks

**Why**: JavaScript error

**Check**:
1. Browser console (F12)
2. Look for red errors
3. Refresh the page

## 📊 What The API Actually Does

When you click "Verify Now":

```
Your Claim: "5G causes COVID-19"
        ↓
Google's API searches its database of 100+ fact-checkers
        ↓
Finds matches from:
  - PolitiFact (USA politics)
  - Snopes (general claims)
  - FactCheck.org (policy/science)
  - AFP Fact Check (international)
  - Lead Stories (viral content)
  - And many more...
        ↓
Returns their verdict + links
        ↓
App calculates Truth Index
        ↓
Shows you the results!
```

## 🎬 For Live Demo

### Opening Statement:
"Let me show you FactFlow verifying a common piece of misinformation..."

### The Demo:
1. **Navigate to Home** (already there)
2. **Say**: "I'll check this claim about 5G and COVID-19"
3. **Paste**: `5G causes COVID-19`
4. **Click Verify**: Point to the button
5. **While loading**: "The app is querying Google's Fact Check API..."
6. **Results appear**: "As you can see, it's been debunked by 5 fact-checkers..."
7. **Click a source**: "We can read the full fact-check here..."
8. **Show Truth Index**: "The credibility score is just 8%"
9. **Show Dark Mode**: "And it works in dark mode too!"
10. **Navigate to Community**: "Users can also see trending claims..."

### Closing:
"All powered by real Google Fact Check API with data from over 100 verified fact-checking organizations worldwide."

## 💡 Pro Tips

### Best Claims to Demo:
- Use controversial but well-known claims
- Avoid brand new news (might not be fact-checked yet)
- Mix TRUE and FALSE claims to show balance

### What Impresses Judges:
1. **Real API integration** (not mocked)
2. **Professional error handling**
3. **Beautiful, smooth animations**
4. **Dark mode support**
5. **Responsive design**
6. **Detailed source information**

### Avoid:
- Super obscure claims (won't have fact-checks)
- Very new events (< 24 hours old)
- Non-English claims (API is primarily English)

## ⚡ Speed Run Test (10 Seconds)

If you just want to verify it works RIGHT NOW:

1. Click "Preview Mode" → "Verify Info"
2. Paste: `5G causes COVID-19`
3. Click "Verify Now"
4. See result appear in 2-3 seconds!

**Done!** ✅

---

## 📞 Need Help?

1. **Check browser console** (F12) for errors
2. **Look at Network tab** to see API calls
3. **Try a different claim** from the examples above
4. **Verify internet connection** is working

## 🎉 You're Ready!

The app is fully functional and ready to demo. Just start testing claims and watch it work!

**Remember**: Not all claims have fact-checks, but the app will always provide analysis based on what's available.

**Happy fact-checking!** 🚀
