# FactFlow - Deployment Guide

## 🚀 Quick Deploy

Choose your preferred platform:

### Option 1: Vercel (Recommended - Fastest)

1. **Install Vercel CLI** (optional):
```bash
npm install -g vercel
```

2. **Deploy**:
```bash
# Login to Vercel
vercel login

# Deploy
vercel
```

Or simply:
- Push to GitHub
- Go to [vercel.com](https://vercel.com)
- Import your repository
- Deploy automatically!

**Add Environment Variable:**
- In Vercel Dashboard → Settings → Environment Variables
- Add: `VITE_GOOGLE_FACT_CHECK_API_KEY` = `AIzaSyBBFGAIFewJowiUS-o8gUtyMxSJhZIDGF4`

### Option 2: Netlify

1. **Install Netlify CLI**:
```bash
npm install -g netlify-cli
```

2. **Deploy**:
```bash
# Login
netlify login

# Deploy
netlify deploy --prod
```

Or via Netlify Dashboard:
- Drag & drop the `dist` folder after building
- Or connect GitHub repository

**Environment Variables:**
- Site settings → Environment variables
- Add: `VITE_GOOGLE_FACT_CHECK_API_KEY`

### Option 3: GitHub Pages

1. **Install gh-pages**:
```bash
npm install --save-dev gh-pages
```

2. **Update package.json**:
```json
{
  "homepage": "https://yourusername.github.io/factflow",
  "scripts": {
    "predeploy": "npm run build",
    "deploy": "gh-pages -d dist"
  }
}
```

3. **Deploy**:
```bash
npm run deploy
```

### Option 4: Railway

1. **Create account** at [railway.app](https://railway.app)
2. **New Project** → Deploy from GitHub
3. **Add environment variable**: `VITE_GOOGLE_FACT_CHECK_API_KEY`
4. Railway auto-detects and deploys!

---

## 📦 Manual Build & Deploy

### Step 1: Install Dependencies
```bash
npm install
```

### Step 2: Create Environment File
```bash
# Copy example file
cp .env.example .env

# Edit .env and add your API key
VITE_GOOGLE_FACT_CHECK_API_KEY=AIzaSyBBFGAIFewJowiUS-o8gUtyMxSJhZIDGF4
```

### Step 3: Build
```bash
npm run build
```

This creates a `dist` folder with production-ready files.

### Step 4: Test Production Build Locally
```bash
npm run preview
```

Opens at `http://localhost:4173`

### Step 5: Deploy `dist` Folder
Upload the `dist` folder to any static hosting:
- AWS S3 + CloudFront
- Google Cloud Storage
- Azure Static Web Apps
- Cloudflare Pages
- Render
- Fly.io

---

## 🔧 Development Setup

### Local Development

1. **Clone/Download** the project

2. **Install dependencies**:
```bash
npm install
```

3. **Create `.env` file**:
```bash
VITE_GOOGLE_FACT_CHECK_API_KEY=AIzaSyBBFGAIFewJowiUS-o8gUtyMxSJhZIDGF4
```

4. **Start development server**:
```bash
npm run dev
```

5. **Open browser**: `http://localhost:3000`

---

## 🌍 Environment Variables

### Production Setup

**Required:**
- `VITE_GOOGLE_FACT_CHECK_API_KEY` - Your Google Fact Check API key

**Optional:**
- `VITE_API_TIMEOUT` - API request timeout (default: 10000ms)
- `VITE_ENABLE_ANALYTICS` - Enable analytics (true/false)

### How to Add in Different Platforms

**Vercel:**
```
Settings → Environment Variables → Add
```

**Netlify:**
```
Site settings → Build & deploy → Environment → Add variable
```

**Railway:**
```
Project → Variables → New Variable
```

**GitHub Actions:**
```yaml
env:
  VITE_GOOGLE_FACT_CHECK_API_KEY: ${{ secrets.API_KEY }}
```

---

## 🔒 Security Best Practices

### 1. API Key Management

**DO:**
- ✅ Use environment variables
- ✅ Add `.env` to `.gitignore`
- ✅ Use different keys for dev/prod
- ✅ Rotate keys periodically

**DON'T:**
- ❌ Commit API keys to Git
- ❌ Share keys publicly
- ❌ Hardcode in source files

### 2. Update API Key in Production

If using the provided key in production, consider:

1. **Get your own API key:**
   - Go to [Google Cloud Console](https://console.cloud.google.com/)
   - Enable "Fact Check Tools API"
   - Create credentials → API Key
   - Add restrictions (HTTP referrers for your domain)

2. **Update environment variable** in your hosting platform

3. **Redeploy** the application

---

## 📊 Build Optimization

### Current Build Configuration

The app is optimized with:
- ✅ Code splitting (React vendor chunks)
- ✅ Minification (Terser)
- ✅ Tree shaking
- ✅ CSS optimization
- ✅ Image optimization

### Build Size

Expected production build:
- **Total**: ~500KB gzipped
- **Initial load**: ~200KB
- **Lazy chunks**: Loaded on demand

### Performance Tips

1. **Enable Compression** on your hosting:
   - Gzip or Brotli compression
   - Most platforms enable this by default

2. **Use CDN**:
   - Vercel/Netlify include CDN
   - Or use Cloudflare

3. **Cache Headers**:
   - Static assets: 1 year
   - HTML: No cache
   - API responses: 5 minutes

---

## 🧪 Testing Before Deployment

### Pre-deployment Checklist

```bash
# 1. Install dependencies
npm install

# 2. Run type checking
npx tsc --noEmit

# 3. Build production
npm run build

# 4. Test production build
npm run preview

# 5. Test key features:
- [ ] Login/Preview mode works
- [ ] Verify a claim with API
- [ ] Dark mode toggle
- [ ] Navigation between screens
- [ ] API returns real results
- [ ] Mobile responsive
- [ ] No console errors
```

### Common Issues

**Build fails:**
```bash
# Clear cache and reinstall
rm -rf node_modules package-lock.json
npm install
npm run build
```

**API not working in production:**
- Check environment variable is set
- Verify API key has no domain restrictions
- Check browser console for CORS errors

**Blank page after deployment:**
- Check browser console
- Verify `index.html` is at root of `dist`
- Check routing configuration

---

## 🎯 Platform-Specific Guides

### Vercel Deployment (Detailed)

1. **Prerequisites:**
   - GitHub/GitLab/Bitbucket account
   - Code pushed to repository

2. **Steps:**
   ```bash
   # Option A: Via CLI
   npm i -g vercel
   vercel login
   vercel
   
   # Option B: Via Dashboard
   # 1. Go to vercel.com/new
   # 2. Import your repository
   # 3. Configure:
   #    - Framework Preset: Vite
   #    - Build Command: npm run build
   #    - Output Directory: dist
   # 4. Add environment variable
   # 5. Deploy
   ```

3. **Custom Domain:**
   - Settings → Domains
   - Add your domain
   - Update DNS records

### Netlify Deployment (Detailed)

1. **Via Drag & Drop:**
   ```bash
   npm run build
   # Drag 'dist' folder to netlify.com/drop
   ```

2. **Via Git:**
   ```bash
   # Connect repository
   # Build settings:
   - Build command: npm run build
   - Publish directory: dist
   - Add environment variables
   ```

3. **Custom Domain:**
   - Domain settings → Add custom domain
   - Update DNS

---

## 📱 Progressive Web App (PWA) - Optional

To make FactFlow installable:

1. **Install PWA plugin:**
```bash
npm install vite-plugin-pwa -D
```

2. **Update vite.config.ts:**
```typescript
import { VitePWA } from 'vite-plugin-pwa'

export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      registerType: 'autoUpdate',
      manifest: {
        name: 'FactFlow',
        short_name: 'FactFlow',
        description: 'AI-powered misinformation detection',
        theme_color: '#3B82F6',
        icons: [
          {
            src: 'factflow-icon.svg',
            sizes: '192x192',
            type: 'image/svg+xml'
          }
        ]
      }
    })
  ]
})
```

---

## 🎉 You're Ready to Deploy!

### Quick Start Commands

```bash
# 1. Install
npm install

# 2. Development
npm run dev

# 3. Build
npm run build

# 4. Preview
npm run preview

# 5. Deploy to Vercel
vercel

# OR Deploy to Netlify
netlify deploy --prod
```

### Live URLs After Deployment

Your app will be available at:
- **Vercel**: `https://factflow.vercel.app` (or your custom domain)
- **Netlify**: `https://factflow.netlify.app` (or your custom domain)
- **GitHub Pages**: `https://username.github.io/factflow`

---

## 🆘 Support

**Issues?** Check:
1. Browser console for errors
2. Network tab for failed requests
3. Build logs for deployment errors
4. Environment variables are set correctly

**Still stuck?**
- Check deployment platform docs
- Verify API key is valid
- Test locally with `npm run preview`

---

**FactFlow is production-ready and deployable in minutes!** 🚀
