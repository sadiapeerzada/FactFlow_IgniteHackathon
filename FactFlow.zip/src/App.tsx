import { useState } from 'react';
import { LoginScreen } from './components/LoginScreen';
import { SplashScreen } from './components/SplashScreen';
import { HomeScreen } from './components/HomeScreen';
import { ResultScreen } from './components/ResultScreen';
import { CommunityScreen } from './components/CommunityScreen';
import { ProfileScreen } from './components/ProfileScreen';
import { FloatingAssistant } from './components/FloatingAssistant';
import { Navigation } from './components/Navigation';
import { Toaster } from 'sonner@2.0.3';

type Screen = 'login' | 'splash' | 'home' | 'result' | 'community' | 'profile';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('login');
  const [resultData, setResultData] = useState<any>(null);
  const [darkMode, setDarkMode] = useState(false);
  const [isPreviewMode, setIsPreviewMode] = useState(false);

  const handleNavigate = (screen: string, data?: any) => {
    setCurrentScreen(screen as Screen);
    if (data) {
      setResultData(data);
    }
  };

  const handlePreviewMode = () => {
    setIsPreviewMode(true);
    setCurrentScreen('splash');
  };

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  const renderScreen = () => {
    switch (currentScreen) {
      case 'login':
        return <LoginScreen onNavigate={handleNavigate} onPreviewMode={handlePreviewMode} />;
      case 'splash':
        return <SplashScreen onNavigate={handleNavigate} />;
      case 'home':
        return <HomeScreen onNavigate={handleNavigate} darkMode={darkMode} onToggleDarkMode={toggleDarkMode} />;
      case 'result':
        return <ResultScreen onNavigate={handleNavigate} data={resultData} />;
      case 'community':
        return <CommunityScreen onNavigate={handleNavigate} darkMode={darkMode} />;
      case 'profile':
        return <ProfileScreen onNavigate={handleNavigate} darkMode={darkMode} onToggleDarkMode={toggleDarkMode} />;
      default:
        return <LoginScreen onNavigate={handleNavigate} onPreviewMode={handlePreviewMode} />;
    }
  };

  return (
    <div className="relative">
      <Toaster position="top-right" />
      <Navigation currentScreen={currentScreen} onNavigate={handleNavigate} />
      
      <div className={currentScreen !== 'splash' && currentScreen !== 'result' && currentScreen !== 'login' ? 'md:pt-16 pb-16 md:pb-0' : ''}>
        {renderScreen()}
      </div>

      {currentScreen !== 'splash' && currentScreen !== 'login' && <FloatingAssistant />}
      
      {/* Preview Mode Badge */}
      {isPreviewMode && currentScreen !== 'login' && (
        <div className="fixed top-4 right-4 z-50 bg-yellow-500 text-white px-4 py-2 rounded-full text-sm shadow-lg">
          Preview Mode
        </div>
      )}
    </div>
  );
}
