import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { MessageCircle, X, Send, Sparkles, Bot, HelpCircle, TrendingUp, Shield } from 'lucide-react';

const sampleMessages = [
  { role: 'assistant', text: 'Hi! 👋 I\'m FactFlow AI Assistant. I can help you verify claims, explain fact-checks, or answer questions about misinformation. How can I assist you today?' },
];

const quickQuestions = [
  { icon: HelpCircle, text: 'How does fact-checking work?' },
  { icon: TrendingUp, text: 'Show trending claims' },
  { icon: Shield, text: 'What is Truth Index?' },
];

export function FloatingAssistant() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState(sampleMessages);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  const sendMessage = (customMessage?: string) => {
    const messageText = customMessage || input;
    if (!messageText.trim()) return;

    // Add user message
    setMessages(prev => [...prev, { role: 'user', text: messageText }]);
    setInput('');
    setIsTyping(true);

    // Simulate AI response
    setTimeout(() => {
      let response = '';
      
      if (messageText.toLowerCase().includes('how') && messageText.toLowerCase().includes('work')) {
        response = 'FactFlow uses multiple fact-checking sources including PolitiFact, Snopes, and FactCheck.org. We analyze claims using Google Fact Check API and generate a Truth Index (0-100%) based on source reliability, community votes, and AI analysis. 🎯';
      } else if (messageText.toLowerCase().includes('trending')) {
        response = 'Top trending claims today:\n\n1️⃣ COVID-19 vaccine claims (8% credibility)\n2️⃣ Climate change data (92% credibility)\n3️⃣ Political statements (varied credibility)\n\nCheck the Community tab for more! 📊';
      } else if (messageText.toLowerCase().includes('truth index')) {
        response = 'The Truth Index is a 0-100% score that combines:\n\n✅ Source Reliability (40%)\n✅ Community Votes (25%)\n✅ AI Analysis (20%)\n✅ Bias Detection (15%)\n\nHigher scores = More trustworthy! 🎯';
      } else {
        response = 'I can help you verify that claim! 🔍 Simply paste the claim in the text box and click "Verify Now" to get real-time fact-checking from 100+ sources. Or ask me anything about FactFlow features!';
      }

      setMessages(prev => [...prev, { role: 'assistant', text: response }]);
      setIsTyping(false);
    }, 1000);
  };

  const handleQuickQuestion = (question: string) => {
    sendMessage(question);
  };

  return (
    <>
      {/* Floating Button */}
      <motion.div
        className="fixed bottom-6 right-6 z-50"
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: 0.5, type: "spring" }}
      >
        <AnimatePresence>
          {!isOpen && (
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0 }}
            >
              <Button
                onClick={() => setIsOpen(true)}
                className="w-16 h-16 rounded-full bg-gradient-to-r from-blue-500 to-teal-500 hover:from-blue-600 hover:to-teal-600 text-white shadow-2xl"
              >
                <motion.div
                  animate={{ rotate: [0, 10, -10, 0] }}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  <Sparkles className="w-6 h-6" />
                </motion.div>
              </Button>
              
              {/* Tooltip */}
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="absolute right-20 top-1/2 -translate-y-1/2 bg-gray-900 text-white px-3 py-2 rounded-lg text-sm whitespace-nowrap"
              >
                Ask FactFlow
                <div className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/2 rotate-45 w-2 h-2 bg-gray-900" />
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="fixed bottom-6 right-6 z-50 w-80 md:w-96"
          >
            <Card className="backdrop-blur-xl bg-white/95 shadow-2xl border-0 overflow-hidden">
              {/* Header */}
              <div className="p-4 bg-gradient-to-r from-blue-500 via-blue-600 to-teal-500 text-white flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <motion.div 
                    className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center backdrop-blur-sm"
                    animate={{ rotate: [0, 360] }}
                    transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                  >
                    <Bot className="w-5 h-5" />
                  </motion.div>
                  <div>
                    <h3 className="font-semibold">FactFlow AI Assistant</h3>
                    <p className="text-xs text-white/90 flex items-center gap-1">
                      <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                      Online • Ready to help
                    </p>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsOpen(false)}
                  className="text-white hover:bg-white/20 h-8 w-8 p-0 rounded-full"
                >
                  <X className="w-5 h-5" />
                </Button>
              </div>

              {/* Messages */}
              <div className="h-96 overflow-y-auto p-4 space-y-4 bg-gradient-to-b from-gray-50 to-white">
                {messages.map((message, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className={`flex gap-2 ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    {message.role === 'assistant' && (
                      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-teal-500 flex items-center justify-center flex-shrink-0 shadow-lg">
                        <Bot className="w-4 h-4 text-white" />
                      </div>
                    )}
                    <div
                      className={`max-w-[75%] p-3 rounded-2xl shadow-md ${
                        message.role === 'user'
                          ? 'bg-gradient-to-r from-blue-500 to-teal-500 text-white rounded-br-sm'
                          : 'bg-white text-gray-800 border border-gray-200 rounded-bl-sm'
                      }`}
                    >
                      <p className="text-sm leading-relaxed whitespace-pre-line">{message.text}</p>
                    </div>
                    {message.role === 'user' && (
                      <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center flex-shrink-0 shadow-lg text-white text-xs">
                        YOU
                      </div>
                    )}
                  </motion.div>
                ))}
                
                {/* Typing indicator */}
                {isTyping && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="flex gap-2 justify-start"
                  >
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-teal-500 flex items-center justify-center flex-shrink-0 shadow-lg">
                      <Bot className="w-4 h-4 text-white" />
                    </div>
                    <div className="bg-white border border-gray-200 p-3 rounded-2xl rounded-bl-sm shadow-md">
                      <div className="flex gap-1">
                        <motion.div 
                          className="w-2 h-2 bg-gray-400 rounded-full"
                          animate={{ y: [0, -5, 0] }}
                          transition={{ duration: 0.6, repeat: Infinity, delay: 0 }}
                        />
                        <motion.div 
                          className="w-2 h-2 bg-gray-400 rounded-full"
                          animate={{ y: [0, -5, 0] }}
                          transition={{ duration: 0.6, repeat: Infinity, delay: 0.2 }}
                        />
                        <motion.div 
                          className="w-2 h-2 bg-gray-400 rounded-full"
                          animate={{ y: [0, -5, 0] }}
                          transition={{ duration: 0.6, repeat: Infinity, delay: 0.4 }}
                        />
                      </div>
                    </div>
                  </motion.div>
                )}

                {/* Quick Questions - Only show at start */}
                {messages.length === 1 && (
                  <div className="space-y-2 pt-2">
                    <p className="text-xs text-gray-500 px-1">Quick questions:</p>
                    {quickQuestions.map((q, i) => (
                      <motion.button
                        key={i}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.5 + i * 0.1 }}
                        onClick={() => handleQuickQuestion(q.text)}
                        className="w-full p-3 bg-white hover:bg-blue-50 border border-gray-200 hover:border-blue-300 rounded-xl text-left transition-all flex items-center gap-2 group"
                      >
                        <q.icon className="w-4 h-4 text-blue-500 group-hover:text-blue-600" />
                        <span className="text-sm text-gray-700 group-hover:text-blue-700">{q.text}</span>
                      </motion.button>
                    ))}
                  </div>
                )}
              </div>

              {/* Input */}
              <div className="p-4 border-t border-gray-200 bg-white">
                <div className="flex gap-2">
                  <Input
                    placeholder="Ask me anything about fact-checking..."
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && !isTyping && sendMessage()}
                    disabled={isTyping}
                    className="flex-1 border-2 border-gray-200 focus:border-blue-400 rounded-xl"
                  />
                  <Button
                    onClick={() => sendMessage()}
                    disabled={!input.trim() || isTyping}
                    className="bg-gradient-to-r from-blue-500 to-teal-500 hover:from-blue-600 hover:to-teal-600 text-white rounded-xl px-4 shadow-lg hover:shadow-xl transition-all"
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
                <p className="text-xs text-gray-400 mt-2 text-center">
                  Powered by FactFlow AI • Ask about claims, sources, or features
                </p>
              </div>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
