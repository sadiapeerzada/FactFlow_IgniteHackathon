# FactFlow - Usage Guide

## 🚀 Google Fact Check API Integration - ACTIVE

FactFlow is now fully integrated with the **Google Fact Check Tools API** using your provided API key.

### How It Works

1. **Enter any claim or URL** in the verification screen
2. Click **"Verify Now"** button
3. The app will:
   - Query Google Fact Check API for existing fact-checks
   - Analyze the text for bias and clickbait
   - Check domain credibility
   - Calculate a comprehensive Truth Index (0-100%)
   - Display results with reasoning and sources

### What Gets Verified

The API checks against verified fact-checking organizations including:
- PolitiFact
- Snopes
- FactCheck.org
- AP Fact Check
- Reuters Fact Check
- AFP Fact Check
- And many more verified fact-checkers

### Example Claims to Test

Try these real claims to see the API in action:

#### **True Claims:**
```
NASA confirms water on Mars
```
```
Climate change is causing global temperatures to rise
```

#### **False Claims:**
```
COVID-19 vaccines contain microchips
```
```
5G towers cause coronavirus
```

#### **Mixed/Uncertain:**
```
Drinking coffee prevents cancer
```

### Understanding Results

#### Truth Index Score (0-100%)
- **70-100%**: Verified/Likely True ✅
  - Multiple fact-checkers confirm
  - Credible sources
  - Minimal bias

- **40-69%**: Uncertain/Mixed ⚠️
  - Some truth, some inaccuracy
  - Requires additional verification
  - Conflicting sources

- **0-39%**: False/Misleading ❌
  - Fact-checkers rate as false
  - Low source credibility
  - High bias/clickbait indicators

#### Score Breakdown

1. **Source Reliability (30%)**: Domain credibility analysis
2. **Bias Score (20%)**: Language neutrality check
3. **Clickbait Detection (15%)**: Sensationalism analysis
4. **Community Trust (15%)**: User feedback (mock data)
5. **Fact-Check Matches (20%)**: Google API results

### Features

✨ **Real-time Verification**
- Live API calls to Google Fact Check
- Instant credibility scoring
- Multiple fact-checker sources

🎯 **Detailed Analysis**
- AI reasoning explanations
- Source-by-source breakdown
- Rating classifications (True/False/Mixed)

🌐 **Domain Reputation**
- Automatic URL extraction
- Known source database
- Credibility categorization

🎨 **Beautiful UI**
- Dark mode support
- Animated score visualizations
- Interactive tooltips

### API Response Example

When you verify a claim, the API returns:

```typescript
{
  truthIndex: 85,
  sourceReliability: 92,
  biasScore: 78,
  clickbaitScore: 88,
  communityScore: 85,
  factCheckResults: [
    {
      text: "Your claim...",
      claimReview: [
        {
          publisher: { name: "PolitiFact" },
          textualRating: "True",
          url: "https://...",
          title: "Fact check review title"
        }
      ]
    }
  ],
  status: "verified",
  reasoning: "Based on 3 fact-check reviews..."
}
```

### Offline Functionality

If the API is unavailable, FactFlow falls back to:
- Local text analysis (bias, clickbait)
- Domain credibility database
- Offline scoring algorithms

### Toast Notifications

- ℹ️ "Analyzing with fact-checking sources..." (Start)
- ✅ "Verification complete!" (Success)
- ❌ "Verification failed. Showing offline analysis." (Error)

### Navigation Flow

```
Login Screen
    ↓ (Login/Preview Mode)
Splash Screen
    ↓ (Verify Info)
Home Screen ← Dark mode toggle
    ↓ (Enter claim + Verify)
    ↓ (API Call to Google)
Result Screen ← Shows API results
    ↓ (Back)
Home Screen
```

### API Key Security

The API key is stored in `/services/factCheck.ts`. For production:

1. Move to environment variables:
```bash
VITE_GOOGLE_FACT_CHECK_API_KEY=your_key_here
```

2. Update code to use:
```typescript
const API_KEY = import.meta.env.VITE_GOOGLE_FACT_CHECK_API_KEY;
```

3. Add to `.gitignore`:
```
.env
.env.local
```

### Rate Limits

Google Fact Check API limits:
- **Free tier**: ~1000 queries/day
- Consider implementing caching for repeated queries
- Store results in localStorage/database

### Error Handling

The app handles:
- ✅ Network errors (falls back to offline analysis)
- ✅ Invalid API responses
- ✅ Empty results
- ✅ Malformed queries

### Performance Tips

1. **Debounce input**: Add 500ms delay before calling API
2. **Cache results**: Store in localStorage by query hash
3. **Batch requests**: Queue multiple verifications
4. **Show loading states**: Current implementation includes spinners

### Browser Extension

The BrowserExtension component (`/components/BrowserExtension.tsx`) can be adapted to:
1. Read current page URL
2. Call verification API automatically
3. Display floating badge with score
4. Quick verify without leaving page

### Community Features

Future enhancements (currently using mock data):
- Real user voting (upvote/downvote)
- Reputation system
- User-submitted fact-checks
- Domain reporting

### Analytics

Track these metrics:
- Verification requests/day
- Average truth index scores
- Most verified domains
- User engagement rates

## 🎯 Try It Now!

1. Start the app
2. Navigate to Home screen
3. Paste this claim: `"COVID-19 vaccines are safe and effective"`
4. Click "Verify Now"
5. Watch the API analyze it in real-time!

## 📊 Success Indicators

You'll know it's working when:
- ✅ Toast appears: "Analyzing with fact-checking sources..."
- ✅ Loading spinner shows during API call
- ✅ Results screen shows actual fact-checker names
- ✅ Truth Index reflects real API ratings
- ✅ Source links are clickable and lead to fact-checks

## 🐛 Troubleshooting

**Issue**: "Verification failed" error
- Check internet connection
- Verify API key is correct
- Check browser console for detailed errors

**Issue**: Low/unexpected scores
- API may not have data for that specific claim
- Try rephrasing or adding more context
- Check if claim includes a recognizable URL

**Issue**: No fact-check sources shown
- Claim may be too new or niche
- Try more well-known claims
- App will still show credibility analysis

## 🎓 For Hackathon Judges

This is a **fully functional** fact-checking app with:
- ✅ Real API integration (Google Fact Check)
- ✅ Live verification results
- ✅ Professional UI/UX
- ✅ Dark mode support
- ✅ Responsive design
- ✅ Error handling
- ✅ Toast notifications
- ✅ Community features (UI ready)

**Tech Stack**: React, TypeScript, Tailwind CSS, Motion, Google Fact Check API

**Ready for**: Demo, testing, and further development!
