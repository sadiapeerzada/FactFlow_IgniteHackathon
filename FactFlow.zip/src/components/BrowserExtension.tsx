import { useState } from 'react';
import { motion } from 'motion/react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Sparkles, Search, CheckCircle2 } from 'lucide-react';

export function BrowserExtension() {
  const [url, setUrl] = useState('');
  const [isChecking, setIsChecking] = useState(false);
  const [result, setResult] = useState<{ score: number; status: string } | null>(null);

  const checkUrl = () => {
    if (!url) return;
    
    setIsChecking(true);
    setTimeout(() => {
      setResult({
        score: Math.floor(Math.random() * 100),
        status: 'verified'
      });
      setIsChecking(false);
    }, 1500);
  };

  return (
    <Card className="w-80 p-4 backdrop-blur-xl bg-white/95 shadow-2xl border-0">
      {/* Header */}
      <div className="flex items-center gap-2 mb-4 pb-3 border-b border-gray-200">
        <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-teal-500 flex items-center justify-center">
          <Sparkles className="w-4 h-4 text-white" />
        </div>
        <div>
          <h3 className="text-gray-800">FactFlow</h3>
          <p className="text-xs text-gray-500">Quick Verify</p>
        </div>
      </div>

      {/* Input */}
      <div className="space-y-3 mb-4">
        <Input
          placeholder="Enter URL or text to verify..."
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          className="border-blue-200 focus:border-blue-400"
        />
        
        <Button
          onClick={checkUrl}
          disabled={!url || isChecking}
          className="w-full bg-gradient-to-r from-blue-500 to-teal-500 hover:from-blue-600 hover:to-teal-600 text-white"
        >
          {isChecking ? (
            <>
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                className="mr-2"
              >
                <Search className="w-4 h-4" />
              </motion.div>
              Checking...
            </>
          ) : (
            <>
              <Search className="w-4 h-4 mr-2" />
              Verify Now
            </>
          )}
        </Button>
      </div>

      {/* Result */}
      {result && (
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="p-3 rounded-lg bg-gradient-to-br from-green-50 to-teal-50"
        >
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-green-500" />
              <span className="text-sm text-gray-800">Verified</span>
            </div>
            <Badge className="bg-green-500 text-white">
              {result.score}%
            </Badge>
          </div>
          <p className="text-xs text-gray-600">
            This information appears to be accurate based on our sources.
          </p>
        </motion.div>
      )}

      {/* Footer */}
      <div className="mt-4 pt-3 border-t border-gray-200">
        <Button variant="link" className="w-full text-xs text-blue-600 p-0">
          View full report
        </Button>
      </div>
    </Card>
  );
}
