# 🚀 Deploy FactFlow in 5 Minutes

## ⚡ Fastest Method: Vercel (Recommended)

### Step-by-Step:

**1. Install Dependencies:**
```bash
npm install
```

**2. Test Locally:**
```bash
npm run dev
```
→ Opens at `http://localhost:3000`

**3. Build:**
```bash
npm run build
```

**4. Deploy to Vercel:**

**Option A - Via Website (No CLI needed):**
1. Go to [vercel.com/new](https://vercel.com/new)
2. Sign up with GitHub
3. Click "Add New" → "Project"
4. Import your repository (or upload files)
5. **Framework Preset:** Vite (auto-detected)
6. **Environment Variables:**
   - Click "Add Environment Variable"
   - Key: `VITE_GOOGLE_FACT_CHECK_API_KEY`
   - Value: `AIzaSyBBFGAIFewJowiUS-o8gUtyMxSJhZIDGF4`
7. Click "Deploy"
8. Wait 2 minutes... ✨
9. **Done!** Your app is live!

**Option B - Via CLI:**
```bash
# Install Vercel CLI
npm i -g vercel

# Login
vercel login

# Deploy
vercel

# Follow prompts:
# - Set up and deploy? Y
# - Which scope? (choose your account)
# - Link to existing project? N
# - Project name? factflow
# - Directory? ./
# - Override settings? N
# - Deploy? Y

# Add environment variable:
vercel env add VITE_GOOGLE_FACT_CHECK_API_KEY
# Paste: AIzaSyBBFGAIFewJowiUS-o8gUtyMxSJhZIDGF4
# Select: Production

# Redeploy with env:
vercel --prod
```

**Your live URL:** `https://factflow-[random].vercel.app`

---

## 🌐 Alternative: Netlify

### Via Drag & Drop (Easiest):

**1. Build the app:**
```bash
npm install
npm run build
```

**2. Deploy:**
- Go to [app.netlify.com/drop](https://app.netlify.com/drop)
- Drag the `dist` folder
- Done! App is live in 30 seconds!

**3. Add Environment Variable:**
- Site settings → Environment variables
- Add: `VITE_GOOGLE_FACT_CHECK_API_KEY`
- Redeploy

### Via Git:

**1. Push to GitHub:**
```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR_USERNAME/factflow.git
git push -u origin main
```

**2. Deploy:**
- Go to [app.netlify.com](https://app.netlify.com)
- New site from Git
- Connect GitHub
- Select repository
- Build command: `npm run build`
- Publish directory: `dist`
- Add environment variable
- Deploy!

---

## 📱 Mobile Testing Before Deploy

```bash
# Run dev server
npm run dev

# Test on your phone:
# 1. Find your IP: ifconfig (Mac/Linux) or ipconfig (Windows)
# 2. Open on phone: http://YOUR_IP:3000
# Example: http://192.168.1.5:3000
```

---

## ✅ Deployment Checklist

Before deploying, ensure:

```bash
# 1. All files are saved
# 2. Run build test
npm run build

# 3. Check build output
# Should see: dist folder created
# Should say: Build completed successfully

# 4. Preview build locally
npm run preview

# 5. Test these features:
```
- [ ] Login/Preview mode works
- [ ] Paste claim and verify
- [ ] API returns results (not mock data)
- [ ] See real fact-checkers (PolitiFact, Snopes)
- [ ] Dark mode toggle
- [ ] Navigate to Community/Profile
- [ ] Mobile responsive (resize browser)
- [ ] No errors in console

---

## 🎯 What Happens After Deployment

### Immediate:
- ✅ Get a live URL (`https://your-app.vercel.app`)
- ✅ Automatic HTTPS (secure)
- ✅ Global CDN (fast worldwide)
- ✅ Auto-deploy on git push

### You Can:
- 📱 Share URL with anyone
- 🌍 Access from any device
- 🔄 Update with git push
- 📊 Monitor with platform analytics
- 🌐 Add custom domain (optional)

---

## 🆘 Troubleshooting

### Build Fails

**Error: "Cannot find module"**
```bash
# Delete and reinstall
rm -rf node_modules package-lock.json
npm install
npm run build
```

**Error: "Type error in TSC"**
```bash
# Ignore type errors for now (not recommended for production)
# Update package.json:
"build": "vite build"
# Remove: "tsc &&"
```

### Deploy Succeeds but Shows Blank Page

**Check:**
1. Browser console (F12) for errors
2. Ensure environment variable is set
3. Try hard refresh (Ctrl+Shift+R)

**Fix:**
```bash
# Rebuild locally
npm run build
npm run preview

# If works locally but not on Vercel:
# - Check Vercel build logs
# - Verify env variable is production
# - Redeploy
```

### API Not Working in Production

**Symptoms:**
- Shows "No fact-checks found"
- Offline analysis only
- Toast says "Verification failed"

**Fix:**
1. **Verify environment variable:**
   - Vercel: Settings → Environment Variables
   - Should see: `VITE_GOOGLE_FACT_CHECK_API_KEY`
   - Click "Redeploy" after adding

2. **Check API key:**
   - Open [Google Cloud Console](https://console.cloud.google.com)
   - APIs & Services → Credentials
   - Check if key has restrictions
   - If restricted, add your Vercel domain

3. **Test API directly:**
   ```
   https://factchecktools.googleapis.com/v1alpha1/claims:search?query=COVID&key=AIzaSyBBFGAIFewJowiUS-o8gUtyMxSJhZIDGF4
   ```
   Should return JSON (not error)

---

## 🎨 Post-Deployment Customization

### Add Custom Domain (Optional)

**Vercel:**
```
1. Buy domain (Namecheap, GoDaddy, etc.)
2. Vercel → Settings → Domains
3. Add domain
4. Update DNS records (copy from Vercel)
5. Wait 24-48 hours for propagation
```

**Netlify:**
```
1. Domain settings → Add custom domain
2. Follow DNS instructions
3. SSL auto-provisions
```

### Add Analytics (Optional)

**Vercel Analytics (Free):**
```bash
npm install @vercel/analytics
```

**Google Analytics:**
Add to `index.html`:
```html
<script async src="https://www.googletagmanager.com/gtag/js?id=YOUR-ID"></script>
```

---

## 🔄 Update Your Deployed App

### After deployment, to update:

**If using Git (Vercel/Netlify):**
```bash
# Make changes to code
# Then:
git add .
git commit -m "Update feature"
git push

# Platform auto-deploys in 2 minutes
```

**If using drag & drop (Netlify):**
```bash
# Make changes
npm run build
# Drag new dist folder to Netlify
```

---

## 📊 Monitoring Your App

### Vercel Dashboard:
- **Deployments:** See all deploys
- **Analytics:** Page views, visitors
- **Functions:** API calls (if any)
- **Logs:** Error tracking

### Netlify Dashboard:
- **Deploys:** Deploy history
- **Forms:** Form submissions
- **Functions:** Serverless logs
- **Analytics:** Traffic (paid)

---

## 🎉 Success Messages

**When deployment works, you'll see:**

**Vercel:**
```
✓ Build completed
✓ Deployment ready
🎉 Assigned to production domain
🔗 https://factflow-xxx.vercel.app
```

**Netlify:**
```
✓ Site is live
🔗 https://factflow-xxx.netlify.app
```

**Local preview:**
```
✓ Built in XXms
➜ Local: http://localhost:4173/
```

---

## 🎯 Final Steps

### 1. Test Your Live App:
```
Visit: https://your-app.vercel.app

Test:
1. Click Preview Mode
2. Verify claim: "5G causes COVID-19"
3. Should see real fact-checkers
4. Should get 5-15% credibility score
5. Links should be clickable
```

### 2. Share It:
```
🎉 Check out FactFlow!
https://your-app.vercel.app

AI-powered fact-checking with Google's API
✅ Real-time verification
✅ 100+ fact-checking sources
✅ Dark mode support
```

### 3. Present It:
```
For judges/demo:
1. Show login screen
2. Click Preview Mode
3. Paste controversial claim
4. Show loading animation
5. Reveal results with sources
6. Click source links
7. Toggle dark mode
8. Show community feed
```

---

## 💰 Cost Breakdown

### Free Tier (Plenty for demos/small projects):

**Vercel:**
- ✅ Unlimited deployments
- ✅ 100GB bandwidth/month
- ✅ HTTPS + CDN
- ✅ Analytics
- ✅ Automatic deployments

**Netlify:**
- ✅ 100GB bandwidth/month
- ✅ 300 build minutes/month
- ✅ HTTPS + CDN
- ✅ Form handling

**GitHub Pages:**
- ✅ Unlimited (for public repos)
- ✅ HTTPS
- ✅ Jekyll/static sites

### Upgrade If:
- 🔥 100K+ monthly visitors
- 🔥 Need serverless functions
- 🔥 Enterprise features

**Most projects never need to upgrade!**

---

## 🎓 What You've Deployed

A production-ready app with:

✅ **Real API Integration** - Google Fact Check
✅ **5 Complete Screens** - Login, Home, Results, Community, Profile
✅ **Dark Mode** - Full theme support
✅ **Responsive Design** - Mobile + Desktop
✅ **Interactive Features** - Voting, badges, tooltips
✅ **Professional UI** - Glassmorphism, animations
✅ **Error Handling** - Graceful fallbacks
✅ **SEO Friendly** - Meta tags, descriptions
✅ **Performance Optimized** - Code splitting, lazy loading
✅ **Secure** - HTTPS, environment variables

---

## ⏱️ Deployment Speed Test

| Platform | Setup | First Deploy | Updates |
|----------|-------|--------------|---------|
| **Vercel** | 2 min | 2 min | 1 min |
| **Netlify** | 2 min | 2 min | 1 min |
| **GitHub Pages** | 5 min | 3 min | 2 min |
| **Railway** | 2 min | 3 min | 2 min |

**Fastest:** Vercel or Netlify

---

## 🚀 Ready? Let's Deploy!

**Choose your path:**

### 🏃 Quick (5 min):
```bash
npm install
npm run build
# Go to vercel.com/new
# Upload files or connect Git
# Add env variable
# Deploy!
```

### 🎯 Recommended (10 min):
```bash
npm install
git init
git add .
git commit -m "Initial"
# Push to GitHub
# Connect Vercel to GitHub
# Auto-deploy on every push
```

### 🧪 Test First (15 min):
```bash
npm install
npm run dev        # Test locally
npm run build      # Build
npm run preview    # Preview build
# Then deploy via Vercel
```

---

**🎉 You're ready to deploy FactFlow and show it to the world!**

**Estimated time to live app:** 5-10 minutes  
**Difficulty:** Beginner-friendly  
**Cost:** $0 (free tier)

**Go for it!** 🚀
