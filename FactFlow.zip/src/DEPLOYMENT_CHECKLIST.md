# ✅ FactFlow Deployment Checklist

## 📋 Pre-Deployment

### Environment Setup
- [ ] Node.js installed (v18+)
- [ ] npm installed
- [ ] Git installed (optional, for Vercel/Netlify)
- [ ] Terminal/Command prompt open

### Files Check
- [ ] All files present in project folder
- [ ] `package.json` exists
- [ ] `vite.config.ts` exists
- [ ] `index.html` exists
- [ ] `main.tsx` exists
- [ ] `/components` folder has all components
- [ ] `/services/factCheck.ts` has API integration

### Local Testing
```bash
# Run these commands:
npm install
npm run dev
```

- [ ] Command runs without errors
- [ ] Opens at `http://localhost:3000`
- [ ] Login screen appears
- [ ] Can click "Preview Mode"
- [ ] Can navigate to Home screen
- [ ] Can paste text in input
- [ ] Can click "Verify Now"
- [ ] Loading spinner appears
- [ ] Results screen shows
- [ ] Fact-checkers appear (PolitiFact, Snopes, etc.)
- [ ] Links are clickable
- [ ] Dark mode toggle works
- [ ] No console errors (F12)

---

## 🔨 Build Testing

### Production Build
```bash
npm run build
```

**Check:**
- [ ] Build completes successfully
- [ ] `dist` folder created
- [ ] No errors in terminal
- [ ] Files in `dist/assets/` exist

### Preview Build
```bash
npm run preview
```

**Test:**
- [ ] Opens at `http://localhost:4173`
- [ ] All features work (same as dev)
- [ ] No console errors
- [ ] API calls work
- [ ] Images load
- [ ] Styles applied correctly

---

## 🚀 Deployment

### Choose Platform
- [ ] **Vercel** (recommended) - 5 min
- [ ] **Netlify** - 5 min  
- [ ] **GitHub Pages** - 10 min
- [ ] Other (Railway, Render, etc.)

### Platform Account
- [ ] Created account
- [ ] Email verified
- [ ] Can access dashboard

### Environment Variables
- [ ] Know your API key: `AIzaSyBBFGAIFewJowiUS-o8gUtyMxSJhZIDGF4`
- [ ] Added to platform:
  - Variable name: `VITE_GOOGLE_FACT_CHECK_API_KEY`
  - Variable value: (your key)
  - Scope: Production

---

## 📤 Vercel Deployment

### Method 1: Website Upload
- [ ] Go to [vercel.com/new](https://vercel.com/new)
- [ ] Sign up/login
- [ ] Click "Add New" → "Project"
- [ ] Upload project folder (or connect Git)
- [ ] Framework: Vite (auto-detected)
- [ ] Add environment variable
- [ ] Click "Deploy"
- [ ] Wait for deployment (2 min)
- [ ] Get live URL
- [ ] Open URL in browser
- [ ] Test app works

### Method 2: CLI
```bash
npm i -g vercel
vercel login
vercel
```

- [ ] CLI installed
- [ ] Logged in
- [ ] Project detected
- [ ] Deployment started
- [ ] Environment variable added
- [ ] Redeployed with: `vercel --prod`
- [ ] Got live URL
- [ ] Tested app

---

## 📤 Netlify Deployment

### Method 1: Drag & Drop
```bash
npm run build
```

- [ ] Build completed
- [ ] `dist` folder exists
- [ ] Go to [app.netlify.com/drop](https://app.netlify.com/drop)
- [ ] Drag `dist` folder
- [ ] Site deployed
- [ ] Got live URL
- [ ] Go to Site Settings → Environment
- [ ] Added environment variable
- [ ] Triggered redeploy
- [ ] Tested app

### Method 2: Git
- [ ] Pushed to GitHub
- [ ] Connected Netlify to GitHub
- [ ] Selected repository
- [ ] Build settings configured
- [ ] Environment variable added
- [ ] Deployed
- [ ] Tested app

---

## 📤 GitHub Pages Deployment

### Setup
```bash
npm install --save-dev gh-pages
```

**package.json updates:**
- [ ] Added `"homepage"` field
- [ ] Added `"predeploy"` script
- [ ] Added `"deploy"` script

**vite.config.ts updates:**
- [ ] Added `base: '/factflow/'`

### Deploy
```bash
npm run deploy
```

- [ ] Deployed to gh-pages branch
- [ ] Go to GitHub → Settings → Pages
- [ ] Source: gh-pages branch
- [ ] Saved settings
- [ ] Waited 2-3 minutes
- [ ] Tested live URL
- [ ] App works

---

## ✅ Post-Deployment Testing

### Live URL Testing

**URL received:** `____________________________`

**Test Checklist:**
- [ ] URL loads (not 404)
- [ ] Login screen appears
- [ ] Click "Preview Mode" works
- [ ] Navigate to Home
- [ ] Paste claim: `5G causes COVID-19`
- [ ] Click "Verify Now"
- [ ] Loading animation shows
- [ ] Results appear
- [ ] Real fact-checkers shown (not generic)
- [ ] Fact-checker links open
- [ ] Score is realistic (5-15% for this claim)
- [ ] Dark mode toggle works
- [ ] Navigate to Community works
- [ ] Navigate to Profile works
- [ ] Mobile responsive (test on phone or resize)
- [ ] No console errors
- [ ] HTTPS enabled (🔒 in URL bar)

### API Verification
- [ ] Open browser DevTools (F12)
- [ ] Go to Network tab
- [ ] Verify a claim
- [ ] See request to `factchecktools.googleapis.com`
- [ ] Response status: 200 OK
- [ ] Response has fact-check data (not empty)

### Cross-Browser Testing
- [ ] Chrome/Edge works
- [ ] Firefox works
- [ ] Safari works (if Mac)
- [ ] Mobile browser works

### Share & Test
- [ ] Share URL with friend
- [ ] They can access it
- [ ] Works for them
- [ ] No login required (preview mode)

---

## 🎯 Success Criteria

### ✅ Deployment Successful If:

1. **Live URL accessible:**
   - Anyone can visit your URL
   - No authentication required
   - Loads in < 3 seconds

2. **Core features work:**
   - Can verify claims
   - API returns real data
   - Navigation works
   - Dark mode toggles
   - Mobile responsive

3. **No critical errors:**
   - No blank pages
   - No console errors
   - No broken links
   - Images load

4. **Professional presentation:**
   - HTTPS enabled
   - Custom or clean URL
   - Fast loading
   - Smooth animations

---

## 🐛 Troubleshooting Checklist

### If Build Fails:
- [ ] Deleted `node_modules`
- [ ] Deleted `package-lock.json`
- [ ] Ran `npm install` again
- [ ] Ran `npm run build` again

### If Blank Page:
- [ ] Checked browser console
- [ ] Verified environment variable is set
- [ ] Checked platform build logs
- [ ] Tried hard refresh (Ctrl+Shift+R)

### If API Not Working:
- [ ] Environment variable name correct
- [ ] Environment variable value correct
- [ ] Redeployed after adding variable
- [ ] Tested API key manually
- [ ] Checked CORS in browser console

### If 404 Errors:
- [ ] Routing configuration correct
- [ ] `vercel.json` or `netlify.toml` present
- [ ] Base URL correct in config
- [ ] Redirects configured

---

## 📊 Platform Status

### Vercel:
- [ ] Deployment status: _______________
- [ ] Build logs: No errors
- [ ] Environment vars: Set correctly
- [ ] Domain: Active
- [ ] SSL: Enabled

### Netlify:
- [ ] Deployment status: _______________
- [ ] Build logs: No errors
- [ ] Environment vars: Set correctly
- [ ] Domain: Active
- [ ] SSL: Enabled

---

## 🎉 Final Steps

### Documentation:
- [ ] Added live URL to README
- [ ] Updated demo instructions
- [ ] Added screenshots (optional)

### Sharing:
- [ ] Shared with team/judges
- [ ] Added to portfolio
- [ ] Posted on social media (optional)
- [ ] Added to resume/CV

### Monitoring:
- [ ] Set up analytics (optional)
- [ ] Monitor error logs
- [ ] Check performance metrics
- [ ] Gather user feedback

---

## 📝 Deployment Info

**Fill this out after deployment:**

```
Platform: ________________ (Vercel/Netlify/etc.)
Live URL: ________________
Deployed: ________________ (date/time)
Environment: Production
API Status: Working ✅ / Not Working ❌
Mobile: Working ✅ / Not Working ❌
Desktop: Working ✅ / Not Working ❌
```

---

## 🎯 Hackathon/Demo Checklist

### Before Presentation:
- [ ] App is deployed and live
- [ ] Tested on presentation computer
- [ ] URL bookmarked
- [ ] Test claims prepared
- [ ] Screenshots ready (backup)
- [ ] Practiced demo flow
- [ ] Backup plan if internet fails

### During Demo:
- [ ] Show login screen
- [ ] Click Preview Mode
- [ ] Navigate smoothly
- [ ] Verify prepared claim
- [ ] Show results with confidence
- [ ] Toggle dark mode
- [ ] Show community features
- [ ] Mention tech stack
- [ ] Share live URL

### After Presentation:
- [ ] Share URL in chat
- [ ] Answer questions
- [ ] Show code (if asked)
- [ ] Gather feedback

---

## ✅ All Done!

**Congratulations!** 🎉

Your FactFlow app is:
- ✅ Deployed
- ✅ Live
- ✅ Working
- ✅ Shareable
- ✅ Demo-ready

**Live URL:** `____________________________`

**Share it with the world!** 🚀

---

**Need help?** Check:
- `DEPLOY_NOW.md` - Quick deployment guide
- `DEPLOYMENT.md` - Detailed instructions
- Platform docs (Vercel, Netlify, etc.)

**You did it!** 🎊
