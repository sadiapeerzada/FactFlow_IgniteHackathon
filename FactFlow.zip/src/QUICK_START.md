# FactFlow - Quick Start Guide

## 🎯 In 30 Seconds

1. **The app is already running** in your browser
2. Click **"Preview Mode"** on login screen
3. Click **"Verify Info"** 
4. Paste this: `COVID-19 vaccines cause autism`
5. Click **"Verify Now"**
6. **Watch the magic happen!** ✨

## 🔥 What Just Happened?

Your input was sent to **Google Fact Check API** which:
- Searched 100+ fact-checking organizations
- Found existing fact-checks
- Returned ratings and sources
- App displayed results with credibility score

## 📍 Where is the API Key?

File: `/services/factCheck.ts`

```typescript
const GOOGLE_FACT_CHECK_API_KEY = 'AIzaSyBBFGAIFewJowiUS-o8gUtyMxSJhZIDGF4';
```

## ✅ Is It Actually Working?

**YES!** You'll know because:

1. **Toast notification** appears: "Analyzing with fact-checking sources..."
2. **Loading spinner** in the Verify button
3. **Results show real fact-checkers**: PolitiFact, Snopes, FactCheck.org
4. **Ratings are real**: "False", "True", "Mixture"
5. **Links are clickable** to actual fact-check articles

## 🎮 Try These Claims

### Will Return Many Results:
```
5G causes coronavirus
```

```
Bill Gates wants to microchip people
```

```
Climate change is a hoax
```

### Will Show TRUE:
```
Joe Biden won 2020 election
```

```
Earth is round
```

## 🏗️ Architecture

```
[User Input] 
    ↓
[HomeScreen.tsx] ← User clicks "Verify Now"
    ↓
[services/factCheck.ts] ← verifyInformation() function
    ↓
[Google Fact Check API] ← API call with your key
    ↓
[API Response] ← JSON with fact-checks
    ↓
[ResultScreen.tsx] ← Display results
```

## 🔍 How to Verify It's Working

### Method 1: Browser DevTools
1. Press `F12`
2. Go to **Network** tab
3. Click "Verify Now" on a claim
4. Look for: `factchecktools.googleapis.com`
5. Click it → Check **Response** tab
6. You should see JSON with fact-check data!

### Method 2: Console Logs
Check the Console tab for:
- ✅ "Verification complete!"
- ❌ Any errors (shows what went wrong)

### Method 3: Visual Confirmation
Real API results have:
- Multiple fact-checker sources
- Different ratings per source
- Clickable URLs to fact-checks
- Specific publisher names

Mock results would have:
- Generic "BBC News", "Reuters"
- All same ratings
- No real URLs

## 🚨 Common Issues

### Issue: "Verification failed" Toast

**Cause**: API returned no results for that claim

**Solution**: 
- Try more well-known claims
- App still shows text analysis
- This is NORMAL for niche topics

### Issue: CORS Error

**Cause**: API key might have domain restrictions

**Solution**:
- Check Google Cloud Console
- Ensure API key allows your domain
- Or remove domain restrictions

### Issue: No Toast/Nothing Happens

**Cause**: Import error or build issue

**Check**:
1. Browser console for errors
2. Verify imports in HomeScreen.tsx
3. Make sure app compiled without errors

## 🎨 Features Already Built

✅ **5 Main Screens**
- Login/Preview
- Home/Verification  
- Results/Truth Index
- Community Feed
- Profile/Settings

✅ **Dark Mode** - Toggle in top-right

✅ **Truth Index Panel** - Live credibility breakdown

✅ **Community Voting** - Upvote/downvote system

✅ **User Badges** - Achievement system

✅ **Browser Extension UI** - Ready to package

## 💡 Code Locations

| Feature | File |
|---------|------|
| API Integration | `/services/factCheck.ts` |
| Verification Screen | `/components/HomeScreen.tsx` |
| Results Display | `/components/ResultScreen.tsx` |
| Truth Index Panel | `/components/TruthIndexPanel.tsx` |
| Community Feed | `/components/CommunityScreen.tsx` |
| Dark Mode Logic | `/App.tsx` |

## 🎓 For Hackathon Demo

**30-Second Pitch:**
> "FactFlow uses Google's Fact Check API to verify claims in real-time. Watch as I paste this vaccine misinformation claim... [paste and verify]... and within seconds, we see it's been debunked by 5 major fact-checkers with an 8% credibility score. The app also analyzes bias, clickbait, and source reliability."

**Show These Features:**
1. ✅ Real API verification
2. ✅ Dark mode toggle
3. ✅ Truth Index breakdown
4. ✅ Community feed
5. ✅ User badges

**Highlight:**
- "Built with React, TypeScript, and Google Fact Check API"
- "Analyzes 100+ verified fact-checking sources"
- "Combines AI text analysis with human fact-checkers"
- "Production-ready with error handling and offline fallback"

## 🔐 Security Note

For production deployment:

1. Move API key to environment variable:
```bash
VITE_GOOGLE_FACT_CHECK_API_KEY=your_key
```

2. Update factCheck.ts:
```typescript
const API_KEY = import.meta.env.VITE_GOOGLE_FACT_CHECK_API_KEY;
```

3. Add to `.gitignore`:
```
.env
.env.local
```

## 🎉 You're Ready!

The app is **fully functional** with a real Google API integration. Just start testing claims and watch it work!

**Questions?** Check the browser console for detailed logs and errors.

**Happy fact-checking!** 🚀
