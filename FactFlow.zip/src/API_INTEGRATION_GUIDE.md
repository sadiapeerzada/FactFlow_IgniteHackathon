# FactFlow API Integration Guide

This guide provides detailed instructions for implementing real fact-checking functionality in FactFlow.

## Overview

FactFlow uses multiple data sources and APIs to calculate a comprehensive Truth Index Score (0-100%) based on:
- Source reliability
- Content bias analysis  
- Clickbait detection
- Community feedback

## Required APIs

### 1. Google Fact Check Tools API

**Purpose**: Cross-reference claims with verified fact-checking organizations

**Setup**:
```bash
# Get API key from: https://console.cloud.google.com/
# Enable Fact Check Tools API
```

**Implementation**:
```typescript
const GOOGLE_FACT_CHECK_API_KEY = 'YOUR_API_KEY_HERE';

async function checkFactGoogle(claim: string) {
  const response = await fetch(
    `https://factchecktools.googleapis.com/v1alpha1/claims:search?query=${encodeURIComponent(claim)}&key=${GOOGLE_FACT_CHECK_API_KEY}`
  );
  const data = await response.json();
  return data.claims;
}
```

### 2. NewsAPI

**Purpose**: Verify if claim appears in reputable news sources

**Setup**:
```bash
# Get API key from: https://newsapi.org/
```

**Implementation**:
```typescript
const NEWS_API_KEY = 'YOUR_API_KEY_HERE';

async function verifyWithNews(query: string) {
  const response = await fetch(
    `https://newsapi.org/v2/everything?q=${encodeURIComponent(query)}&apiKey=${NEWS_API_KEY}&sources=bbc-news,reuters,associated-press`
  );
  const data = await response.json();
  return data.articles;
}
```

### 3. Hugging Face NLP API (Text Analysis)

**Purpose**: Analyze text for bias, sentiment, and clickbait indicators

**Setup**:
```bash
# Get API token from: https://huggingface.co/settings/tokens
```

**Implementation**:
```typescript
const HF_API_TOKEN = 'YOUR_TOKEN_HERE';

async function analyzeTextBias(text: string) {
  const response = await fetch(
    'https://api-inference.huggingface.co/models/facebook/bart-large-mnli',
    {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${HF_API_TOKEN}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        inputs: text,
        parameters: {
          candidate_labels: ["neutral", "biased", "clickbait", "factual"]
        }
      })
    }
  );
  return await response.json();
}
```

### 4. Custom Domain Reputation Database

**Purpose**: Check source website credibility

**Implementation**:
```typescript
// Use a service like Cloudflare Radar or build your own database
const domainReputationDB = {
  'reuters.com': { credibility: 98, category: 'high' },
  'bbc.com': { credibility: 95, category: 'high' },
  'apnews.com': { credibility: 96, category: 'high' },
  'nature.com': { credibility: 97, category: 'high' },
  'fake-news-site.com': { credibility: 5, category: 'low' },
  // Add more domains
};

function checkDomainCredibility(url: string) {
  const domain = new URL(url).hostname.replace('www.', '');
  return domainReputationDB[domain] || { credibility: 50, category: 'medium' };
}
```

## Truth Index Calculation

```typescript
interface VerificationData {
  sourceReliability: number;    // 0-100
  biasScore: number;            // 0-100 (higher = less biased)
  clickbaitScore: number;       // 0-100 (higher = not clickbait)
  communityScore: number;       // 0-100
  factCheckMatches: number;     // Number of fact-check confirmations
}

function calculateTruthIndex(data: VerificationData): number {
  const weights = {
    sourceReliability: 0.30,
    biasScore: 0.20,
    clickbaitScore: 0.15,
    communityScore: 0.20,
    factCheckMatches: 0.15
  };

  const factCheckBonus = Math.min(data.factCheckMatches * 10, 15);
  
  const score = (
    data.sourceReliability * weights.sourceReliability +
    data.biasScore * weights.biasScore +
    data.clickbaitScore * weights.clickbaitScore +
    data.communityScore * weights.communityScore +
    factCheckBonus
  );

  return Math.min(Math.round(score), 100);
}
```

## Complete Verification Flow

```typescript
async function verifyInformation(input: string) {
  try {
    // 1. Extract URL if present
    const urlMatch = input.match(/https?:\/\/[^\s]+/);
    const url = urlMatch ? urlMatch[0] : null;
    
    // 2. Check domain credibility if URL exists
    let sourceReliability = 50;
    let domainCredibility = 'medium';
    if (url) {
      const domainData = checkDomainCredibility(url);
      sourceReliability = domainData.credibility;
      domainCredibility = domainData.category;
    }

    // 3. Check with Google Fact Check API
    const factCheckResults = await checkFactGoogle(input);
    const factCheckMatches = factCheckResults?.length || 0;
    
    // 4. Verify with News API
    const newsArticles = await verifyWithNews(input);
    if (newsArticles.length > 0) {
      sourceReliability = Math.max(sourceReliability, 70);
    }

    // 5. Analyze text for bias and clickbait
    const textAnalysis = await analyzeTextBias(input);
    const biasScore = calculateBiasScore(textAnalysis);
    const clickbaitScore = calculateClickbaitScore(input, textAnalysis);

    // 6. Get community feedback (from database)
    const communityScore = await getCommunityScore(input);

    // 7. Calculate final Truth Index
    const truthIndex = calculateTruthIndex({
      sourceReliability,
      biasScore,
      clickbaitScore,
      communityScore,
      factCheckMatches
    });

    return {
      truthIndex,
      sourceReliability,
      biasScore,
      clickbaitScore,
      communityScore,
      domainCredibility,
      factCheckSources: factCheckResults,
      newsArticles: newsArticles.slice(0, 4)
    };
  } catch (error) {
    console.error('Verification error:', error);
    throw error;
  }
}
```

## Browser Extension Implementation

The browser extension monitors the current page and provides instant verification.

**manifest.json**:
```json
{
  "manifest_version": 3,
  "name": "FactFlow - Truth Verification",
  "version": "1.0.0",
  "permissions": ["activeTab", "storage"],
  "action": {
    "default_popup": "popup.html"
  },
  "content_scripts": [{
    "matches": ["<all_urls>"],
    "js": ["content.js"]
  }]
}
```

**content.js** (inject badge):
```javascript
// Get current page URL
const currentUrl = window.location.href;

// Call verification API
fetch('https://your-api.com/verify', {
  method: 'POST',
  body: JSON.stringify({ url: currentUrl })
})
.then(res => res.json())
.then(data => {
  // Inject floating badge showing Truth Index
  const badge = document.createElement('div');
  badge.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 999999;
    background: white;
    padding: 12px;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
  `;
  badge.innerHTML = `
    <div style="font-size: 12px; color: #666;">Truth Index</div>
    <div style="font-size: 24px; font-weight: bold; color: ${getScoreColor(data.score)};">
      ${data.score}%
    </div>
  `;
  document.body.appendChild(badge);
});
```

## Community Verification System

### Database Schema (Example with Supabase)

```sql
-- Users table
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email TEXT UNIQUE NOT NULL,
  reputation INTEGER DEFAULT 0,
  badges JSONB DEFAULT '[]',
  created_at TIMESTAMP DEFAULT NOW()
);

-- Verifications table
CREATE TABLE verifications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id),
  content TEXT NOT NULL,
  url TEXT,
  truth_index INTEGER NOT NULL,
  source_reliability INTEGER,
  bias_score INTEGER,
  clickbait_score INTEGER,
  community_score INTEGER,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Community votes table
CREATE TABLE community_votes (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  verification_id UUID REFERENCES verifications(id),
  user_id UUID REFERENCES users(id),
  vote_type TEXT CHECK (vote_type IN ('up', 'down', 'flag')),
  created_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(verification_id, user_id)
);

-- Domain reputation table
CREATE TABLE domain_reputation (
  domain TEXT PRIMARY KEY,
  credibility_score INTEGER NOT NULL,
  category TEXT NOT NULL,
  reports_count INTEGER DEFAULT 0,
  verified_by_admin BOOLEAN DEFAULT FALSE,
  updated_at TIMESTAMP DEFAULT NOW()
);
```

### Reputation System

```typescript
// Award reputation points based on activity
const REPUTATION_REWARDS = {
  VERIFY_CLAIM: 5,
  ACCURATE_REPORT: 10,
  HELPFUL_VOTE: 1,
  BADGE_EARNED: 50
};

async function updateUserReputation(userId: string, action: string) {
  const points = REPUTATION_REWARDS[action] || 0;
  
  // Update user reputation
  await supabase
    .from('users')
    .update({ 
      reputation: supabase.raw('reputation + ?', [points]) 
    })
    .eq('id', userId);
    
  // Check for badge eligibility
  await checkAndAwardBadges(userId);
}
```

## Security Considerations

1. **Rate Limiting**: Implement API rate limits to prevent abuse
2. **API Key Security**: Store API keys in environment variables, never in client code
3. **Input Validation**: Sanitize all user inputs before processing
4. **CORS**: Configure proper CORS headers for API endpoints
5. **Authentication**: Use secure JWT tokens for user authentication

## Testing

```typescript
// Mock verification for testing
const mockVerificationData = {
  truthIndex: 85,
  sourceReliability: 92,
  biasScore: 78,
  clickbaitScore: 88,
  communityScore: 85,
  domainCredibility: 'high',
  factCheckSources: [
    { publisher: 'Reuters', rating: 'True' },
    { publisher: 'BBC', rating: 'True' }
  ]
};
```

## Next Steps

1. Sign up for all required API services
2. Set up a backend server (Node.js, Python, etc.) to handle API calls securely
3. Implement database for community features
4. Deploy verification endpoint
5. Build and test browser extension
6. Implement caching to reduce API calls
7. Add analytics to track verification accuracy

## Resources

- [Google Fact Check Tools API Docs](https://developers.google.com/fact-check/tools/api)
- [NewsAPI Documentation](https://newsapi.org/docs)
- [Hugging Face Inference API](https://huggingface.co/docs/api-inference)
- [Chrome Extension Development](https://developer.chrome.com/docs/extensions/)
- [Supabase Documentation](https://supabase.com/docs)
