import { useState } from 'react';
import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Textarea } from './ui/textarea';
import { Search, Upload, TrendingUp, CheckCircle2, XCircle, AlertCircle, Moon, Sun, Mic, Image as ImageIcon, Sparkles } from 'lucide-react';
import { Badge } from './ui/badge';
import { TruthIndexPanel } from './TruthIndexPanel';
import { verifyInformation } from '../services/factCheck';
import { toast } from 'sonner@2.0.3';

interface HomeScreenProps {
  onNavigate: (screen: string, data?: any) => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
}

const recentStories = [
  {
    id: 1,
    title: "New COVID-19 vaccine causes magnetism",
    status: "false",
    score: 12,
    date: "2 hours ago"
  },
  {
    id: 2,
    title: "Scientists discover water on Mars",
    status: "true",
    score: 94,
    date: "5 hours ago"
  },
  {
    id: 3,
    title: "Celebrity announces retirement",
    status: "uncertain",
    score: 56,
    date: "1 day ago"
  },
  {
    id: 4,
    title: "New climate policy approved by EU",
    status: "true",
    score: 88,
    date: "2 days ago"
  }
];

export function HomeScreen({ onNavigate, darkMode, onToggleDarkMode }: HomeScreenProps) {
  const [inputText, setInputText] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [currentScore, setCurrentScore] = useState(85);
  const [isRecording, setIsRecording] = useState(false);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);

  const handleAnalyze = async () => {
    if (!inputText.trim()) {
      toast.error('Please enter some text to verify');
      return;
    }
    
    setIsAnalyzing(true);
    
    try {
      toast.info('Analyzing with fact-checking sources...');
      const result = await verifyInformation(inputText);
      
      setIsAnalyzing(false);
      setCurrentScore(result.truthIndex);
      
      // Navigate to results with real API data
      onNavigate('result', { 
        text: inputText,
        verificationResult: result
      });
      
      toast.success('Verification complete!');
    } catch (error) {
      setIsAnalyzing(false);
      console.error('Verification error:', error);
      toast.error('Verification failed. Showing offline analysis.');
      
      // Still navigate with partial data
      onNavigate('result', { 
        text: inputText,
        verificationResult: null
      });
    }
  };

  const handleVoiceInput = () => {
    setIsRecording(!isRecording);
    if (!isRecording) {
      toast.success('Voice input activated! (Demo mode)');
      // Simulate voice input
      setTimeout(() => {
        setInputText('COVID-19 vaccines contain microchips for tracking');
        setIsRecording(false);
        toast.info('Voice transcription complete');
      }, 2000);
    } else {
      toast.info('Voice input stopped');
    }
  };

  const handleImageUpload = () => {
    toast.info('Image upload feature (Demo mode)');
    // Simulate image upload
    setUploadedImage('demo-image');
    toast.success('Image uploaded! AI analysis ready');
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'true':
        return <CheckCircle2 className="w-4 h-4 text-green-500" />;
      case 'false':
        return <XCircle className="w-4 h-4 text-red-500" />;
      default:
        return <AlertCircle className="w-4 h-4 text-yellow-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'true':
        return 'bg-green-500';
      case 'false':
        return 'bg-red-500';
      default:
        return 'bg-yellow-500';
    }
  };

  return (
    <div className={`min-h-screen ${darkMode ? 'dark bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900' : 'bg-gradient-to-br from-blue-50 via-white to-teal-50'} py-8 px-4`}>
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Header */}
            <motion.div
              initial={{ y: -20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              className="mb-12"
            >
              <div className="flex items-center justify-between mb-4">
                <h1 className="text-4xl md:text-5xl bg-gradient-to-r from-blue-600 to-teal-600 bg-clip-text text-transparent">
                  Verify Information
                </h1>
                <Button
                  variant="outline"
                  size="icon"
                  onClick={onToggleDarkMode}
                  className={`rounded-full ${darkMode ? 'border-gray-600 text-yellow-400 hover:bg-gray-800' : 'border-gray-300 text-gray-600 hover:bg-gray-100'}`}
                >
                  {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
                </Button>
              </div>
              <p className={darkMode ? "text-gray-400" : "text-gray-600"}>
                Paste any news, claim, or link to check its credibility
              </p>
            </motion.div>

            {/* Main Input Card */}
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.2 }}
            >
              <Card className={`p-6 md:p-8 backdrop-blur-xl ${darkMode ? 'bg-gray-800/80 border-gray-700' : 'bg-white/80 border-blue-100'} shadow-2xl border-2`}>
                <div className="space-y-6">
                  {/* Text Input Area */}
                  <div className="relative">
                    <Textarea
                      placeholder="Paste a news headline, article link, or claim here... 📰"
                      value={inputText}
                      onChange={(e) => setInputText(e.target.value)}
                      className={`min-h-[140px] resize-none border-2 rounded-xl ${darkMode ? 'border-gray-600 bg-gray-700/50 text-white placeholder:text-gray-400 focus:border-blue-400' : 'border-blue-100 placeholder:text-gray-400 focus:border-blue-400'} text-base transition-all`}
                    />
                    
                    {/* Character count */}
                    {inputText.length > 0 && (
                      <div className={`absolute bottom-3 right-3 text-xs ${darkMode ? 'text-gray-500' : 'text-gray-400'}`}>
                        {inputText.length} characters
                      </div>
                    )}
                  </div>

                  {/* Image Upload Preview */}
                  {uploadedImage && (
                    <motion.div
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className={`p-4 rounded-xl border-2 ${darkMode ? 'bg-gray-700/50 border-gray-600' : 'bg-blue-50 border-blue-200'} flex items-center gap-3`}
                    >
                      <ImageIcon className="w-8 h-8 text-blue-500" />
                      <div className="flex-1">
                        <p className={`text-sm ${darkMode ? 'text-white' : 'text-gray-800'}`}>Image uploaded</p>
                        <p className={`text-xs ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>AI analysis ready</p>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setUploadedImage(null)}
                        className="text-red-500 hover:text-red-600"
                      >
                        Remove
                      </Button>
                    </motion.div>
                  )}
                  
                  {/* Action Buttons */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    {/* Analyze Button - Large & Prominent */}
                    <Button
                      onClick={handleAnalyze}
                      disabled={!inputText.trim() || isAnalyzing}
                      className="sm:col-span-2 bg-gradient-to-r from-blue-500 via-blue-600 to-teal-500 hover:from-blue-600 hover:via-blue-700 hover:to-teal-600 text-white py-7 rounded-xl shadow-lg hover:shadow-xl transition-all relative overflow-hidden group disabled:opacity-50"
                    >
                      {isAnalyzing ? (
                        <>
                          <motion.div
                            animate={{ rotate: 360 }}
                            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                            className="mr-2"
                          >
                            <Sparkles className="w-6 h-6" />
                          </motion.div>
                          Analyzing with AI...
                        </>
                      ) : (
                        <>
                          <Search className="w-6 h-6 mr-2" />
                          <span>Verify Now</span>
                        </>
                      )}
                      
                      {/* Shine effect */}
                      <motion.div
                        className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent"
                        initial={{ x: '-100%' }}
                        animate={{ x: '200%' }}
                        transition={{ duration: 2, repeat: Infinity, repeatDelay: 1 }}
                      />
                    </Button>

                    {/* Voice Input Button */}
                    <Button
                      onClick={handleVoiceInput}
                      variant="outline"
                      className={`border-2 py-7 rounded-xl transition-all ${
                        isRecording 
                          ? 'border-red-500 bg-red-50 text-red-600 animate-pulse' 
                          : darkMode 
                            ? 'border-gray-600 text-purple-400 hover:bg-gray-700 hover:border-purple-500' 
                            : 'border-purple-300 text-purple-600 hover:bg-purple-50 hover:border-purple-400'
                      }`}
                    >
                      <Mic className={`w-5 h-5 ${isRecording ? 'animate-pulse' : ''}`} />
                    </Button>
                  </div>

                  {/* Secondary Actions */}
                  <div className="grid grid-cols-2 gap-3">
                    <Button
                      onClick={handleImageUpload}
                      variant="outline"
                      className={`border-2 py-5 rounded-xl transition-all ${darkMode ? 'border-gray-600 text-teal-400 hover:bg-gray-700 hover:border-teal-500' : 'border-teal-300 text-teal-600 hover:bg-teal-50 hover:border-teal-400'}`}
                    >
                      <Upload className="w-5 h-5 mr-2" />
                      Upload Image
                    </Button>

                    <Button
                      variant="outline"
                      className={`border-2 py-5 rounded-xl transition-all ${darkMode ? 'border-gray-600 text-blue-400 hover:bg-gray-700 hover:border-blue-500' : 'border-blue-300 text-blue-600 hover:bg-blue-50 hover:border-blue-400'}`}
                    >
                      <ImageIcon className="w-5 h-5 mr-2" />
                      AI Image Analysis
                    </Button>
                  </div>

                  {/* Quick Tips */}
                  <div className={`mt-4 p-4 rounded-xl ${darkMode ? 'bg-gray-700/30' : 'bg-blue-50/50'} border ${darkMode ? 'border-gray-600' : 'border-blue-100'}`}>
                    <p className={`text-sm ${darkMode ? 'text-gray-300' : 'text-gray-700'} mb-2`}>
                      <span className="font-medium">💡 Quick Tips:</span>
                    </p>
                    <ul className={`text-xs space-y-1 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                      <li>• Paste news headlines, claims, or article links</li>
                      <li>• Use voice input for hands-free verification</li>
                      <li>• Upload images with text for AI analysis</li>
                    </ul>
                  </div>
                </div>
              </Card>
            </motion.div>

            {/* Recently Verified Stories */}
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.4 }}
              className="mt-12"
            >
              <div className="flex items-center gap-2 mb-6">
                <TrendingUp className="w-5 h-5 text-blue-600" />
                <h2 className={`text-2xl ${darkMode ? 'text-white' : 'text-gray-800'}`}>Recently Verified Stories</h2>
              </div>

              <div className="space-y-3">
                {recentStories.map((story, index) => (
                  <motion.div
                    key={story.id}
                    initial={{ x: -20, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: 0.5 + index * 0.1 }}
                  >
                    <Card className={`p-4 backdrop-blur-xl ${darkMode ? 'bg-gray-800/60 hover:bg-gray-800/80' : 'bg-white/60 hover:bg-white/80'} border-0 shadow-lg hover:shadow-xl transition-all cursor-pointer group`}>
                      <div className="flex items-center gap-4">
                        <div className={`w-2 h-2 rounded-full ${getStatusColor(story.status)}`} />
                        
                        <div className="flex-1 min-w-0">
                          <p className={`${darkMode ? 'text-white group-hover:text-teal-400' : 'text-gray-800 group-hover:text-blue-600'} transition-colors truncate`}>
                            {story.title}
                          </p>
                          <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>{story.date}</p>
                        </div>

                        <div className="flex items-center gap-3">
                          <Badge 
                            variant="secondary"
                            className={darkMode ? 'bg-blue-900/50 text-blue-300' : 'bg-blue-100 text-blue-700'}
                          >
                            {story.score}%
                          </Badge>
                          {getStatusIcon(story.status)}
                        </div>
                      </div>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>

          {/* Truth Index Sidebar */}
          <div className="hidden lg:block lg:col-span-1">
            <motion.div
              initial={{ x: 20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: 0.3 }}
            >
              <TruthIndexPanel
                score={currentScore}
                sourceReliability={92}
                biasScore={78}
                clickbaitScore={88}
                communityScore={85}
              />
            </motion.div>
          </div>
        </div>

        {/* Quick Action Floating Buttons */}
        <motion.div
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.6 }}
          className="fixed right-6 bottom-24 flex flex-col gap-3 z-40"
        >
          {/* Voice Assistant Quick Action */}
          <motion.div
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            className="group relative"
          >
            <Button
              onClick={handleVoiceInput}
              className={`w-14 h-14 rounded-full shadow-xl transition-all ${
                isRecording
                  ? 'bg-gradient-to-br from-red-500 to-red-600 animate-pulse'
                  : 'bg-gradient-to-br from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700'
              }`}
            >
              <Mic className="w-6 h-6 text-white" />
            </Button>
            <div className="absolute right-16 top-1/2 -translate-y-1/2 bg-gray-900 text-white px-3 py-2 rounded-lg text-sm whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
              {isRecording ? 'Recording...' : 'Voice Assistant'}
              <div className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/2 rotate-45 w-2 h-2 bg-gray-900" />
            </div>
          </motion.div>

          {/* Upload Image Quick Action */}
          <motion.div
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            className="group relative"
          >
            <Button
              onClick={handleImageUpload}
              className="w-14 h-14 rounded-full bg-gradient-to-br from-teal-500 to-teal-600 hover:from-teal-600 hover:to-teal-700 shadow-xl"
            >
              <Upload className="w-6 h-6 text-white" />
            </Button>
            <div className="absolute right-16 top-1/2 -translate-y-1/2 bg-gray-900 text-white px-3 py-2 rounded-lg text-sm whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
              Upload Image
              <div className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/2 rotate-45 w-2 h-2 bg-gray-900" />
            </div>
          </motion.div>

          {/* AI Analysis Quick Action */}
          <motion.div
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            className="group relative"
          >
            <Button
              className="w-14 h-14 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 shadow-xl"
            >
              <ImageIcon className="w-6 h-6 text-white" />
            </Button>
            <div className="absolute right-16 top-1/2 -translate-y-1/2 bg-gray-900 text-white px-3 py-2 rounded-lg text-sm whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
              AI Image Analysis
              <div className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/2 rotate-45 w-2 h-2 bg-gray-900" />
            </div>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
}
