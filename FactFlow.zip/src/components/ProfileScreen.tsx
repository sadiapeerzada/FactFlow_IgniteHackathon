import { useState } from 'react';
import { motion } from 'motion/react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Switch } from './ui/switch';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback } from './ui/avatar';
import { Separator } from './ui/separator';
import { User, History, Settings, LogOut, CheckCircle2, XCircle, AlertCircle, Moon, Sun, Award, Shield, Star, TrendingUp, Zap } from 'lucide-react';

interface ProfileScreenProps {
  onNavigate: (screen: string) => void;
  darkMode?: boolean;
  onToggleDarkMode?: () => void;
}

const userBadges = [
  { id: 1, name: 'Truth Seeker', icon: Shield, description: 'Verified 10 claims', color: 'text-blue-500', bgColor: 'bg-blue-100' },
  { id: 2, name: 'Fact Hunter', icon: Star, description: 'Verified 50 claims', color: 'text-purple-500', bgColor: 'bg-purple-100' },
  { id: 3, name: 'Community Hero', icon: Award, description: '100 helpful votes', color: 'text-yellow-500', bgColor: 'bg-yellow-100' },
  { id: 4, name: 'Early Adopter', icon: Zap, description: 'Joined in first month', color: 'text-green-500', bgColor: 'bg-green-100' },
  { id: 5, name: 'Trend Spotter', icon: TrendingUp, description: 'Spotted 5 viral claims', color: 'text-teal-500', bgColor: 'bg-teal-100' },
];

const verificationHistory = [
  {
    id: 1,
    title: "Scientists discover water on Mars",
    date: "Oct 10, 2025",
    status: "verified",
    score: 94
  },
  {
    id: 2,
    title: "New COVID-19 vaccine causes magnetism",
    date: "Oct 9, 2025",
    status: "false",
    score: 12
  },
  {
    id: 3,
    title: "Celebrity announces retirement",
    date: "Oct 8, 2025",
    status: "uncertain",
    score: 56
  },
  {
    id: 4,
    title: "New climate policy approved by EU",
    date: "Oct 7, 2025",
    status: "verified",
    score: 88
  },
  {
    id: 5,
    title: "Tech company announces layoffs",
    date: "Oct 6, 2025",
    status: "verified",
    score: 91
  }
];

const availableAPIs = [
  { name: 'Google Fact Check API', enabled: true },
  { name: 'PolitiFact API', enabled: true },
  { name: 'Snopes API', enabled: false },
  { name: 'FactCheck.org API', enabled: true },
  { name: 'Full Fact API', enabled: false }
];

export function ProfileScreen({ onNavigate, darkMode = false, onToggleDarkMode }: ProfileScreenProps) {
  const [apis, setApis] = useState(availableAPIs);

  const toggleAPI = (index: number) => {
    const newApis = [...apis];
    newApis[index].enabled = !newApis[index].enabled;
    setApis(newApis);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'verified':
        return <CheckCircle2 className="w-5 h-5 text-green-500" />;
      case 'false':
        return <XCircle className="w-5 h-5 text-red-500" />;
      default:
        return <AlertCircle className="w-5 h-5 text-yellow-500" />;
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 70) return 'bg-green-100 text-green-700';
    if (score >= 40) return 'bg-yellow-100 text-yellow-700';
    return 'bg-red-100 text-red-700';
  };

  return (
    <div className={`min-h-screen ${darkMode ? 'dark bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900' : 'bg-gradient-to-br from-blue-50 via-white to-teal-50'} py-8 px-4`}>
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="mb-8"
        >
          <h1 className="text-4xl md:text-5xl mb-2 bg-gradient-to-r from-blue-600 to-teal-600 bg-clip-text text-transparent">
            Profile & Settings
          </h1>
          <p className={darkMode ? "text-gray-400" : "text-gray-600"}>
            Manage your account and preferences
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* User Info Card */}
          <motion.div
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="lg:col-span-1"
          >
            <Card className={`p-6 backdrop-blur-xl ${darkMode ? 'bg-gray-800/80' : 'bg-white/80'} shadow-xl border-0 sticky top-8`}>
              <div className="text-center">
                <Avatar className="w-24 h-24 mx-auto mb-4">
                  <AvatarFallback className="bg-gradient-to-br from-blue-500 to-teal-500 text-white text-2xl">
                    JD
                  </AvatarFallback>
                </Avatar>
                
                <h2 className={`text-xl mb-1 ${darkMode ? 'text-white' : 'text-gray-800'}`}>John Doe</h2>
                <p className={darkMode ? "text-gray-400 mb-2" : "text-gray-500 mb-2"}>john.doe@email.com</p>
                
                {/* Reputation Score */}
                <div className="mb-4">
                  <div className="flex items-center justify-center gap-2">
                    <Award className="w-5 h-5 text-yellow-500" />
                    <span className={`text-sm ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                      Reputation: <span className="text-blue-600">342</span>
                    </span>
                  </div>
                </div>
                
                <div className="space-y-2 mb-6">
                  <div className={`flex items-center justify-between p-2 ${darkMode ? 'bg-blue-900/30' : 'bg-blue-50'} rounded-lg`}>
                    <span className={`text-sm ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>Verifications</span>
                    <Badge variant="secondary" className={darkMode ? 'bg-blue-900 text-blue-300' : 'bg-blue-100 text-blue-700'}>
                      {verificationHistory.length}
                    </Badge>
                  </div>
                  <div className={`flex items-center justify-between p-2 ${darkMode ? 'bg-teal-900/30' : 'bg-teal-50'} rounded-lg`}>
                    <span className={`text-sm ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>Member Since</span>
                    <span className={`text-sm ${darkMode ? 'text-white' : 'text-gray-800'}`}>Jan 2025</span>
                  </div>
                </div>

                <Separator className="mb-6" />

                <div className="space-y-2">
                  <Button variant="outline" className="w-full justify-start">
                    <User className="w-4 h-4 mr-2" />
                    Edit Profile
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Settings className="w-4 h-4 mr-2" />
                    Settings
                  </Button>
                  <Button variant="outline" className="w-full justify-start text-red-600 hover:text-red-700 hover:bg-red-50">
                    <LogOut className="w-4 h-4 mr-2" />
                    Logout
                  </Button>
                </div>
              </div>
            </Card>
          </motion.div>

          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Badges Section */}
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.3 }}
            >
              <Card className={`p-6 backdrop-blur-xl ${darkMode ? 'bg-gray-800/80' : 'bg-white/80'} shadow-xl border-0`}>
                <div className="flex items-center gap-2 mb-4">
                  <Award className="w-5 h-5 text-blue-600" />
                  <h3 className={`text-xl ${darkMode ? 'text-white' : 'text-gray-800'}`}>Your Badges</h3>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {userBadges.map((badge, index) => {
                    const Icon = badge.icon;
                    return (
                      <motion.div
                        key={badge.id}
                        initial={{ scale: 0.8, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        transition={{ delay: 0.4 + index * 0.05 }}
                        className={`p-4 rounded-lg text-center ${darkMode ? 'bg-gray-700/50' : badge.bgColor} transition-transform hover:scale-105 cursor-pointer`}
                      >
                        <Icon className={`w-8 h-8 mx-auto mb-2 ${badge.color}`} />
                        <p className={`text-sm mb-1 ${darkMode ? 'text-white' : 'text-gray-800'}`}>{badge.name}</p>
                        <p className={`text-xs ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>{badge.description}</p>
                      </motion.div>
                    );
                  })}
                </div>
              </Card>
            </motion.div>

            {/* Verification History */}
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.4 }}
            >
              <Card className={`p-6 backdrop-blur-xl ${darkMode ? 'bg-gray-800/80' : 'bg-white/80'} shadow-xl border-0`}>
                <div className="flex items-center gap-2 mb-4">
                  <History className="w-5 h-5 text-blue-600" />
                  <h3 className={`text-xl ${darkMode ? 'text-white' : 'text-gray-800'}`}>Verification History</h3>
                </div>

                <div className="space-y-3">
                  {verificationHistory.map((item, index) => (
                    <motion.div
                      key={item.id}
                      initial={{ x: -20, opacity: 0 }}
                      animate={{ x: 0, opacity: 1 }}
                      transition={{ delay: 0.5 + index * 0.05 }}
                      className={`flex items-center gap-4 p-3 rounded-lg ${darkMode ? 'bg-gray-700/50 hover:bg-gray-700' : 'bg-gray-50 hover:bg-gray-100'} transition-colors cursor-pointer`}
                    >
                      {getStatusIcon(item.status)}
                      
                      <div className="flex-1 min-w-0">
                        <p className={`truncate ${darkMode ? 'text-white' : 'text-gray-800'}`}>{item.title}</p>
                        <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>{item.date}</p>
                      </div>

                      <Badge className={getScoreColor(item.score)}>
                        {item.score}%
                      </Badge>
                    </motion.div>
                  ))}
                </div>

                <Button variant="outline" className={`w-full mt-4 ${darkMode ? 'border-gray-600 text-gray-300 hover:bg-gray-700' : ''}`}>
                  View All History
                </Button>
              </Card>
            </motion.div>

            {/* API Settings */}
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.6 }}
            >
              <Card className={`p-6 backdrop-blur-xl ${darkMode ? 'bg-gray-800/80' : 'bg-white/80'} shadow-xl border-0`}>
                <div className="flex items-center gap-2 mb-4">
                  <Settings className="w-5 h-5 text-blue-600" />
                  <h3 className={`text-xl ${darkMode ? 'text-white' : 'text-gray-800'}`}>Fact-Checking APIs</h3>
                </div>
                <p className={`mb-4 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                  Choose which fact-checking sources to use for verification
                </p>

                <div className="space-y-3">
                  {apis.map((api, index) => (
                    <motion.div
                      key={index}
                      initial={{ x: -20, opacity: 0 }}
                      animate={{ x: 0, opacity: 1 }}
                      transition={{ delay: 0.7 + index * 0.05 }}
                      className={`flex items-center justify-between p-3 rounded-lg ${darkMode ? 'bg-gray-700/50' : 'bg-gray-50'}`}
                    >
                      <span className={darkMode ? 'text-white' : 'text-gray-800'}>{api.name}</span>
                      <Switch
                        checked={api.enabled}
                        onCheckedChange={() => toggleAPI(index)}
                      />
                    </motion.div>
                  ))}
                </div>
              </Card>
            </motion.div>

            {/* Appearance Settings */}
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.8 }}
            >
              <Card className={`p-6 backdrop-blur-xl ${darkMode ? 'bg-gray-800/80' : 'bg-white/80'} shadow-xl border-0`}>
                <h3 className={`text-xl mb-4 ${darkMode ? 'text-white' : 'text-gray-800'}`}>Appearance</h3>
                
                <div className={`flex items-center justify-between p-4 rounded-lg ${darkMode ? 'bg-gray-700/50' : 'bg-gray-50'}`}>
                  <div className="flex items-center gap-3">
                    {darkMode ? (
                      <Moon className="w-5 h-5 text-blue-600" />
                    ) : (
                      <Sun className="w-5 h-5 text-yellow-600" />
                    )}
                    <div>
                      <p className={darkMode ? 'text-white' : 'text-gray-800'}>Dark Mode</p>
                      <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                        {darkMode ? 'Dark theme enabled' : 'Light theme enabled'}
                      </p>
                    </div>
                  </div>
                  <Switch
                    checked={darkMode}
                    onCheckedChange={onToggleDarkMode}
                  />
                </div>
              </Card>
            </motion.div>

            {/* Feedback Section */}
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.8 }}
            >
              <Card className="p-6 backdrop-blur-xl bg-white/80 shadow-xl border-0">
                <h3 className="text-xl mb-4 text-gray-800">Help & Feedback</h3>
                
                <div className="space-y-2">
                  <Button variant="outline" className="w-full justify-start">
                    Send Feedback
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    Report a Bug
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    Help Center
                  </Button>
                </div>
              </Card>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}
