import { motion } from 'motion/react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Shield, AlertTriangle, CheckCircle2, Info } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from './ui/tooltip';

interface TruthIndexPanelProps {
  score: number;
  sourceReliability: number;
  biasScore: number;
  clickbaitScore: number;
  communityScore: number;
}

export function TruthIndexPanel({
  score,
  sourceReliability,
  biasScore,
  clickbaitScore,
  communityScore
}: TruthIndexPanelProps) {
  const getScoreColor = (value: number) => {
    if (value >= 70) return 'text-green-500';
    if (value >= 40) return 'text-yellow-500';
    return 'text-red-500';
  };

  const getScoreBg = (value: number) => {
    if (value >= 70) return 'bg-green-500';
    if (value >= 40) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const getScoreLabel = (value: number) => {
    if (value >= 70) return 'High';
    if (value >= 40) return 'Moderate';
    return 'Low';
  };

  const getScoreIcon = (value: number) => {
    if (value >= 70) return <CheckCircle2 className="w-5 h-5 text-green-500" />;
    if (value >= 40) return <AlertTriangle className="w-5 h-5 text-yellow-500" />;
    return <Shield className="w-5 h-5 text-red-500" />;
  };

  return (
    <Card className="p-6 backdrop-blur-xl bg-white/90 dark:bg-gray-900/90 shadow-xl border-0 sticky top-20">
      <div className="flex items-center gap-2 mb-6">
        <Shield className="w-6 h-6 text-blue-600" />
        <h3 className="text-xl text-gray-800 dark:text-white">Truth Index</h3>
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger>
              <Info className="w-4 h-4 text-gray-400" />
            </TooltipTrigger>
            <TooltipContent>
              <p className="max-w-xs">
                Combined credibility score based on source reliability, content analysis, and community feedback
              </p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>

      {/* Main Score */}
      <div className="text-center mb-6">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", duration: 0.8 }}
          className="relative inline-block"
        >
          <svg className="w-32 h-32 transform -rotate-90">
            <circle
              cx="64"
              cy="64"
              r="56"
              stroke="currentColor"
              strokeWidth="8"
              fill="none"
              className="text-gray-200 dark:text-gray-700"
            />
            <motion.circle
              cx="64"
              cy="64"
              r="56"
              stroke="currentColor"
              strokeWidth="8"
              fill="none"
              strokeLinecap="round"
              strokeDasharray={`${2 * Math.PI * 56}`}
              initial={{ strokeDashoffset: 2 * Math.PI * 56 }}
              animate={{ strokeDashoffset: 2 * Math.PI * 56 * (1 - score / 100) }}
              transition={{ duration: 1.5, ease: "easeOut" }}
              className={getScoreColor(score)}
            />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center">
              <p className={`text-3xl ${getScoreColor(score)}`}>{score}</p>
              <p className="text-xs text-gray-500">/ 100</p>
            </div>
          </div>
        </motion.div>

        <div className="mt-4">
          <Badge className={`${getScoreBg(score)} text-white`}>
            {getScoreLabel(score)} Credibility
          </Badge>
        </div>
      </div>

      {/* Breakdown Metrics */}
      <div className="space-y-4">
        {/* Source Reliability */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-700 dark:text-gray-300">Source Reliability</span>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger>
                    <Info className="w-3 h-3 text-gray-400" />
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Trustworthiness of the source domain</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
            <span className="text-sm text-gray-900 dark:text-white">{sourceReliability}%</span>
          </div>
          <div className="relative h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${sourceReliability}%` }}
              transition={{ duration: 1, delay: 0.2 }}
              className={`h-full ${getScoreBg(sourceReliability)}`}
            />
          </div>
        </div>

        {/* Bias Score */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-700 dark:text-gray-300">Unbiased Content</span>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger>
                    <Info className="w-3 h-3 text-gray-400" />
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>AI analysis of language bias and neutrality</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
            <span className="text-sm text-gray-900 dark:text-white">{biasScore}%</span>
          </div>
          <div className="relative h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${biasScore}%` }}
              transition={{ duration: 1, delay: 0.4 }}
              className={`h-full ${getScoreBg(biasScore)}`}
            />
          </div>
        </div>

        {/* Clickbait Detection */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-700 dark:text-gray-300">Not Clickbait</span>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger>
                    <Info className="w-3 h-3 text-gray-400" />
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Detection of sensationalized headlines</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
            <span className="text-sm text-gray-900 dark:text-white">{clickbaitScore}%</span>
          </div>
          <div className="relative h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${clickbaitScore}%` }}
              transition={{ duration: 1, delay: 0.6 }}
              className={`h-full ${getScoreBg(clickbaitScore)}`}
            />
          </div>
        </div>

        {/* Community Score */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-700 dark:text-gray-300">Community Trust</span>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger>
                    <Info className="w-3 h-3 text-gray-400" />
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Verification from community fact-checkers</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
            <span className="text-sm text-gray-900 dark:text-white">{communityScore}%</span>
          </div>
          <div className="relative h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${communityScore}%` }}
              transition={{ duration: 1, delay: 0.8 }}
              className={`h-full ${getScoreBg(communityScore)}`}
            />
          </div>
        </div>
      </div>

      {/* AI Reasoning */}
      <div className="mt-6 p-4 rounded-lg bg-blue-50 dark:bg-blue-900/20">
        <h4 className="text-sm mb-2 text-gray-800 dark:text-white flex items-center gap-2">
          {getScoreIcon(score)}
          AI Reasoning
        </h4>
        <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">
          {score >= 70 
            ? "This content shows high credibility with strong source reliability. Analysis indicates minimal bias and alignment with verified fact-checking standards."
            : score >= 40
            ? "Mixed credibility signals detected. Some elements are verifiable while others require additional fact-checking from multiple sources."
            : "Low credibility detected. Multiple indicators suggest misinformation including unreliable sources, biased language, or contradictory evidence. Verify before sharing."}
        </p>
      </div>

      {/* Powered by Google Fact Check */}
      <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
        <p className="text-xs text-center text-gray-500 dark:text-gray-400">
          Powered by Google Fact Check Tools API
        </p>
      </div>
    </Card>
  );
}
