import { useState } from 'react';
import { motion } from 'motion/react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsList, TabsTrigger } from './ui/tabs';
import { Flag, TrendingUp, Eye, ThumbsUp, ThumbsDown, AlertTriangle, Award } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface CommunityScreenProps {
  onNavigate: (screen: string) => void;
  darkMode?: boolean;
}

const trendingStories = [
  {
    id: 1,
    title: "New AI breakthrough claims 100% accuracy in disease detection",
    category: "Technology",
    credibility: 45,
    views: "2.4K",
    thumbnail: "https://images.unsplash.com/photo-1677442136019-21780ecad995?w=400&h=250&fit=crop",
    status: "uncertain",
    upvotes: 142,
    downvotes: 38,
    domain: "tech-news-daily.com",
    domainCredibility: "medium"
  },
  {
    id: 2,
    title: "Government announces new climate emergency measures",
    category: "Politics",
    credibility: 88,
    views: "5.1K",
    thumbnail: "https://images.unsplash.com/photo-1473186578172-c141e6798cf4?w=400&h=250&fit=crop",
    status: "verified",
    upvotes: 523,
    downvotes: 47,
    domain: "reuters.com",
    domainCredibility: "high"
  },
  {
    id: 3,
    title: "Miracle cure for common cold discovered by researchers",
    category: "Health",
    credibility: 12,
    views: "8.3K",
    thumbnail: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=400&h=250&fit=crop",
    status: "false",
    upvotes: 15,
    downvotes: 892,
    domain: "fake-health-news.net",
    domainCredibility: "low"
  },
  {
    id: 4,
    title: "Tech giant announces revolutionary quantum computer",
    category: "Technology",
    credibility: 92,
    views: "4.7K",
    thumbnail: "https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=400&h=250&fit=crop",
    status: "verified",
    upvotes: 673,
    downvotes: 22,
    domain: "bbc.com",
    domainCredibility: "high"
  },
  {
    id: 5,
    title: "New study links social media to mental health issues",
    category: "Health",
    credibility: 76,
    views: "3.2K",
    thumbnail: "https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=400&h=250&fit=crop",
    status: "verified",
    upvotes: 412,
    downvotes: 89,
    domain: "nature.com",
    domainCredibility: "high"
  },
  {
    id: 6,
    title: "Celebrity endorses dangerous health trend",
    category: "Health",
    credibility: 8,
    views: "12K",
    thumbnail: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400&h=250&fit=crop",
    status: "false",
    upvotes: 23,
    downvotes: 1234,
    domain: "celeb-gossip-daily.com",
    domainCredibility: "low"
  },
  {
    id: 7,
    title: "Space agency confirms signs of life on distant planet",
    category: "Global",
    credibility: 34,
    views: "15K",
    thumbnail: "https://images.unsplash.com/photo-1614728894747-a83421e2b9c9?w=400&h=250&fit=crop",
    status: "uncertain",
    upvotes: 287,
    downvotes: 412,
    domain: "space-rumors.org",
    domainCredibility: "low"
  },
  {
    id: 8,
    title: "Major policy shift in international trade agreements",
    category: "Politics",
    credibility: 81,
    views: "2.9K",
    thumbnail: "https://images.unsplash.com/photo-1526304640581-d334cdbbf45e?w=400&h=250&fit=crop",
    status: "verified",
    upvotes: 356,
    downvotes: 45,
    domain: "apnews.com",
    domainCredibility: "high"
  }
];

export function CommunityScreen({ onNavigate, darkMode = false }: CommunityScreenProps) {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [votedStories, setVotedStories] = useState<Record<number, 'up' | 'down' | null>>({});

  const filteredStories = selectedCategory === 'All' 
    ? trendingStories 
    : trendingStories.filter(story => story.category === selectedCategory);

  const handleVote = (storyId: number, vote: 'up' | 'down') => {
    setVotedStories(prev => ({
      ...prev,
      [storyId]: prev[storyId] === vote ? null : vote
    }));
  };

  const getCredibilityColor = (score: number) => {
    if (score >= 70) return 'bg-green-500';
    if (score >= 40) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'verified':
        return <Badge className="bg-green-100 text-green-700">Verified</Badge>;
      case 'false':
        return <Badge className="bg-red-100 text-red-700">False</Badge>;
      default:
        return <Badge className="bg-yellow-100 text-yellow-700">Uncertain</Badge>;
    }
  };

  const getDomainBadge = (credibility: string) => {
    switch (credibility) {
      case 'high':
        return <Badge variant="outline" className="border-green-500 text-green-700 bg-green-50">Trusted Source</Badge>;
      case 'low':
        return <Badge variant="outline" className="border-red-500 text-red-700 bg-red-50 flex items-center gap-1">
          <AlertTriangle className="w-3 h-3" />
          Low Credibility Domain
        </Badge>;
      default:
        return <Badge variant="outline" className="border-yellow-500 text-yellow-700 bg-yellow-50">Unverified Source</Badge>;
    }
  };

  return (
    <div className={`min-h-screen ${darkMode ? 'dark bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900' : 'bg-gradient-to-br from-blue-50 via-white to-teal-50'} py-8 px-4`}>
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="mb-8"
        >
          <div className="flex items-center gap-3 mb-2">
            <TrendingUp className="w-8 h-8 text-blue-600" />
            <h1 className="text-4xl md:text-5xl bg-gradient-to-r from-blue-600 to-teal-600 bg-clip-text text-transparent">
              Community Feed
            </h1>
          </div>
          <div className="flex items-center justify-between">
            <p className={darkMode ? "text-gray-400" : "text-gray-600"}>
              Explore trending stories and fact-checked content from our community
            </p>
            <div className="hidden md:flex items-center gap-2">
              <Award className="w-5 h-5 text-yellow-500" />
              <span className={`text-sm ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                Your Reputation: <span className="text-blue-600">342</span>
              </span>
            </div>
          </div>
        </motion.div>

        {/* Filter Tabs */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="mb-8"
        >
          <Tabs value={selectedCategory} onValueChange={setSelectedCategory} className="w-full">
            <TabsList className="w-full justify-start overflow-x-auto flex-wrap h-auto bg-white/80 backdrop-blur-xl p-2">
              <TabsTrigger value="All" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-500 data-[state=active]:to-teal-500 data-[state=active]:text-white">
                All
              </TabsTrigger>
              <TabsTrigger value="Politics" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-500 data-[state=active]:to-teal-500 data-[state=active]:text-white">
                Politics
              </TabsTrigger>
              <TabsTrigger value="Health" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-500 data-[state=active]:to-teal-500 data-[state=active]:text-white">
                Health
              </TabsTrigger>
              <TabsTrigger value="Technology" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-500 data-[state=active]:to-teal-500 data-[state=active]:text-white">
                Technology
              </TabsTrigger>
              <TabsTrigger value="Global" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-500 data-[state=active]:to-teal-500 data-[state=active]:text-white">
                Global
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </motion.div>

        {/* Stories Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredStories.map((story, index) => (
            <motion.div
              key={story.id}
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: index * 0.05 }}
            >
              <Card className="overflow-hidden backdrop-blur-xl bg-white/80 shadow-lg hover:shadow-2xl transition-all border-0 group cursor-pointer">
                {/* Thumbnail */}
                <div className="relative h-48 overflow-hidden">
                  <ImageWithFallback
                    src={story.thumbnail}
                    alt={story.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute top-3 right-3">
                    {getStatusBadge(story.status)}
                  </div>
                  <div className="absolute top-3 left-3">
                    <Badge variant="secondary" className="bg-black/50 text-white backdrop-blur-sm">
                      {story.category}
                    </Badge>
                  </div>
                </div>

                {/* Content */}
                <div className="p-4">
                  <h3 className={`mb-2 line-clamp-2 transition-colors ${darkMode ? 'text-white group-hover:text-teal-400' : 'text-gray-800 group-hover:text-blue-600'}`}>
                    {story.title}
                  </h3>

                  {/* Domain Badge */}
                  <div className="mb-3">
                    <div className="flex items-center gap-2 mb-1">
                      <span className={`text-xs ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>{story.domain}</span>
                      {getDomainBadge(story.domainCredibility)}
                    </div>
                  </div>

                  {/* Credibility Bar */}
                  <div className="mb-3">
                    <div className="flex items-center justify-between mb-1">
                      <span className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>Credibility</span>
                      <span className={`text-sm ${darkMode ? 'text-white' : 'text-gray-800'}`}>{story.credibility}%</span>
                    </div>
                    <div className={`w-full h-2 ${darkMode ? 'bg-gray-700' : 'bg-gray-200'} rounded-full overflow-hidden`}>
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${story.credibility}%` }}
                        transition={{ duration: 1, delay: index * 0.05 }}
                        className={`h-full ${getCredibilityColor(story.credibility)}`}
                      />
                    </div>
                  </div>

                  {/* Community Voting */}
                  <div className={`flex items-center justify-between py-2 px-3 rounded-lg ${darkMode ? 'bg-gray-700/50' : 'bg-gray-50'} mb-3`}>
                    <div className="flex items-center gap-3">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleVote(story.id, 'up');
                        }}
                        className={`flex items-center gap-1 transition-colors ${
                          votedStories[story.id] === 'up'
                            ? 'text-green-600'
                            : darkMode ? 'text-gray-400 hover:text-green-400' : 'text-gray-600 hover:text-green-600'
                        }`}
                      >
                        <ThumbsUp className="w-4 h-4" />
                        <span className="text-sm">{story.upvotes + (votedStories[story.id] === 'up' ? 1 : 0)}</span>
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleVote(story.id, 'down');
                        }}
                        className={`flex items-center gap-1 transition-colors ${
                          votedStories[story.id] === 'down'
                            ? 'text-red-600'
                            : darkMode ? 'text-gray-400 hover:text-red-400' : 'text-gray-600 hover:text-red-600'
                        }`}
                      >
                        <ThumbsDown className="w-4 h-4" />
                        <span className="text-sm">{story.downvotes + (votedStories[story.id] === 'down' ? 1 : 0)}</span>
                      </button>
                    </div>
                    <div className={`flex items-center gap-1 text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                      <Eye className="w-4 h-4" />
                      {story.views}
                    </div>
                  </div>

                  {/* Footer */}
                  <div className={`flex items-center justify-between pt-2 border-t ${darkMode ? 'border-gray-700' : 'border-gray-100'}`}>
                    <Button 
                      variant="ghost" 
                      size="sm"
                      className={darkMode ? 'text-gray-400 hover:text-red-400' : 'text-gray-500 hover:text-red-500'}
                      onClick={(e) => e.stopPropagation()}
                    >
                      <Flag className="w-4 h-4 mr-1" />
                      Report
                    </Button>
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
