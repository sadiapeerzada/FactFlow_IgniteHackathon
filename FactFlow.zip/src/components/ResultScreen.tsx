import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { ArrowLeft, ExternalLink, ThumbsUp, ThumbsDown, Flag, Share2, CheckCircle2, Loader2 } from 'lucide-react';
import { Avatar, AvatarFallback } from './ui/avatar';
import { VerificationResult } from '../services/factCheck';

interface ResultScreenProps {
  onNavigate: (screen: string) => void;
  data?: {
    text: string;
    verificationResult?: VerificationResult | null;
  };
}

const userFeedback = [
  { user: 'Sarah M.', comment: 'Verified this from multiple sources. Accurate!', helpful: 24, time: '2h ago' },
  { user: 'John D.', comment: 'Thanks for the detailed breakdown.', helpful: 18, time: '5h ago' },
  { user: 'Emily R.', comment: 'The source comparison is really helpful.', helpful: 31, time: '1d ago' }
];

export function ResultScreen({ onNavigate, data }: ResultScreenProps) {
  const verificationResult = data?.verificationResult;
  const [trustScore, setTrustScore] = useState(verificationResult?.truthIndex || 50);
  const [isLiked, setIsLiked] = useState(false);
  const [isDisliked, setIsDisliked] = useState(false);
  const [sources, setSources] = useState<any[]>([]);

  useEffect(() => {
    if (verificationResult?.factCheckResults) {
      // Convert fact-check results to sources format
      const factCheckSources = verificationResult.factCheckResults.flatMap(claim => 
        claim.claimReview?.map(review => ({
          name: review.publisher.name,
          reliability: 90, // Default high reliability for fact-checkers
          url: review.publisher.site || new URL(review.url).hostname,
          rating: review.textualRating,
          reviewUrl: review.url
        })) || []
      );
      
      setSources(factCheckSources.length > 0 ? factCheckSources : [
        { name: 'Analysis Complete', reliability: verificationResult.sourceReliability, url: 'factflow.ai' }
      ]);
    } else {
      setSources([
        { name: 'Offline Analysis', reliability: 50, url: 'factflow.ai' }
      ]);
    }
  }, [verificationResult]);

  const getTrustColor = (score: number) => {
    if (score >= 70) return 'text-green-500';
    if (score >= 40) return 'text-yellow-500';
    return 'text-red-500';
  };

  const getTrustBg = (score: number) => {
    if (score >= 70) return 'from-green-400 to-green-600';
    if (score >= 40) return 'from-yellow-400 to-yellow-600';
    return 'from-red-400 to-red-600';
  };

  const getTrustLabel = (score: number) => {
    if (score >= 70) return 'Likely Accurate';
    if (score >= 40) return 'Uncertain';
    return 'Likely False';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-teal-50 py-8 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="mb-8"
        >
          <Button
            variant="ghost"
            onClick={() => onNavigate('home')}
            className="mb-4 text-blue-600 hover:text-blue-700 hover:bg-blue-50"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Verify
          </Button>
          
          <h1 className="text-3xl md:text-4xl bg-gradient-to-r from-blue-600 to-teal-600 bg-clip-text text-transparent">
            Verification Report
          </h1>
          <p className="text-gray-600 mt-2">Analyzed: "{data?.text?.substring(0, 100)}{data?.text && data.text.length > 100 ? '...' : ''}"</p>
        </motion.div>

        {/* Trust Score Card with Enhanced Hover */}
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.2 }}
          whileHover={{ scale: 1.02, boxShadow: "0 25px 50px -12px rgba(0, 0, 0, 0.25)" }}
        >
          <Card className="p-8 backdrop-blur-xl bg-white/80 shadow-2xl border-0 mb-6 transition-all duration-300">
            <div className="flex flex-col md:flex-row items-center gap-8">
              {/* Circular Progress */}
              <div className="relative">
                <svg className="w-40 h-40 transform -rotate-90">
                  <circle
                    cx="80"
                    cy="80"
                    r="70"
                    stroke="currentColor"
                    strokeWidth="12"
                    fill="none"
                    className="text-gray-200"
                  />
                  <motion.circle
                    cx="80"
                    cy="80"
                    r="70"
                    stroke="url(#gradient)"
                    strokeWidth="12"
                    fill="none"
                    strokeLinecap="round"
                    strokeDasharray={`${2 * Math.PI * 70}`}
                    initial={{ strokeDashoffset: 2 * Math.PI * 70 }}
                    animate={{ strokeDashoffset: 2 * Math.PI * 70 * (1 - trustScore / 100) }}
                    transition={{ duration: 1.5, ease: "easeOut" }}
                  />
                  <defs>
                    <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" className={trustScore >= 70 ? "stop-green-400" : trustScore >= 40 ? "stop-yellow-400" : "stop-red-400"} />
                      <stop offset="100%" className={trustScore >= 70 ? "stop-green-600" : trustScore >= 40 ? "stop-yellow-600" : "stop-red-600"} />
                    </linearGradient>
                  </defs>
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <motion.p
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ delay: 0.5, type: "spring" }}
                      className={`text-4xl ${getTrustColor(trustScore)}`}
                    >
                      {trustScore}%
                    </motion.p>
                    <p className="text-sm text-gray-500">Trust Score</p>
                  </div>
                </div>
              </div>

              {/* Summary */}
              <div className="flex-1 text-center md:text-left">
                <Badge className={`bg-gradient-to-r ${getTrustBg(trustScore)} text-white mb-4`}>
                  {verificationResult?.status === 'verified' ? 'Verified' : 
                   verificationResult?.status === 'false' ? 'False' : 
                   getTrustLabel(trustScore)}
                </Badge>
                <h3 className="text-xl mb-3 text-gray-800">AI Analysis Summary</h3>
                <p className="text-gray-600 leading-relaxed">
                  {verificationResult?.summary || `Based on our analysis, this claim has a credibility score of ${trustScore}%.`}
                </p>
                {verificationResult?.factCheckResults && verificationResult.factCheckResults.length > 0 && (
                  <p className="text-sm text-gray-500 mt-2">
                    Found {verificationResult.factCheckResults.length} fact-check review{verificationResult.factCheckResults.length > 1 ? 's' : ''} from verified sources.
                  </p>
                )}
                
                {/* Action Buttons */}
                <div className="flex flex-wrap gap-3 mt-6">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setIsLiked(!isLiked)}
                    className={isLiked ? 'bg-blue-50 border-blue-300' : ''}
                  >
                    <ThumbsUp className="w-4 h-4 mr-1" />
                    Helpful
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setIsDisliked(!isDisliked)}
                    className={isDisliked ? 'bg-red-50 border-red-300' : ''}
                  >
                    <ThumbsDown className="w-4 h-4 mr-1" />
                    Not Helpful
                  </Button>
                  <Button variant="outline" size="sm">
                    <Share2 className="w-4 h-4 mr-1" />
                    Share
                  </Button>
                  <Button variant="outline" size="sm">
                    <Flag className="w-4 h-4 mr-1" />
                    Report
                  </Button>
                </div>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Verified Sources */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="mb-6"
        >
          <Card className="p-6 backdrop-blur-xl bg-white/80 shadow-xl border-0">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl text-gray-800">Verified Sources Used</h3>
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm" className="text-blue-600 border-blue-300">
                    View Source Comparison
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Source Comparison</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 max-h-96 overflow-y-auto">
                    {sources.map((source, index) => (
                      <Card key={index} className="p-4">
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <h4 className="text-gray-800">{source.name}</h4>
                            <p className="text-sm text-gray-500">{source.url}</p>
                          </div>
                          <div className="flex flex-col items-end gap-1">
                            <Badge variant="secondary">{source.reliability}% reliable</Badge>
                            {source.rating && (
                              <Badge className={
                                source.rating.toLowerCase().includes('true') ? 'bg-green-100 text-green-700' :
                                source.rating.toLowerCase().includes('false') ? 'bg-red-100 text-red-700' :
                                'bg-yellow-100 text-yellow-700'
                              }>
                                {source.rating}
                              </Badge>
                            )}
                          </div>
                        </div>
                        <p className="text-sm text-gray-600">
                          {source.rating 
                            ? `Rating: ${source.rating}. This fact-checker has reviewed the claim.`
                            : 'This source confirms the main claims with supporting evidence and contextual information.'}
                        </p>
                        {source.reviewUrl && (
                          <Button 
                            variant="link" 
                            size="sm" 
                            className="px-0 text-blue-600"
                            onClick={() => window.open(source.reviewUrl, '_blank')}
                          >
                            Read full fact-check <ExternalLink className="w-3 h-3 ml-1" />
                          </Button>
                        )}
                      </Card>
                    ))}
                  </div>
                </DialogContent>
              </Dialog>
            </div>

            <div className="space-y-3">
              {sources.map((source, index) => (
                <motion.div
                  key={index}
                  initial={{ x: -20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: 0.5 + index * 0.1 }}
                  className="flex items-center justify-between p-3 rounded-lg bg-blue-50/50 hover:bg-blue-50 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-green-500" />
                    <div>
                      <p className="text-gray-800">{source.name}</p>
                      <p className="text-sm text-gray-500">{source.url}</p>
                    </div>
                  </div>
                  <Badge variant="secondary" className="bg-blue-100 text-blue-700">
                    {source.reliability}%
                  </Badge>
                </motion.div>
              ))}
            </div>
          </Card>
        </motion.div>

        {/* User Feedback */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.6 }}
        >
          <Card className="p-6 backdrop-blur-xl bg-white/80 shadow-xl border-0">
            <h3 className="text-xl mb-4 text-gray-800">User Feedback</h3>
            
            <div className="space-y-4">
              {userFeedback.map((feedback, index) => (
                <motion.div
                  key={index}
                  initial={{ x: -20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: 0.7 + index * 0.1 }}
                  className="flex gap-3 pb-4 border-b border-gray-100 last:border-0"
                >
                  <Avatar>
                    <AvatarFallback className="bg-gradient-to-br from-blue-400 to-teal-400 text-white">
                      {feedback.user.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                  
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-gray-800">{feedback.user}</p>
                      <p className="text-sm text-gray-500">{feedback.time}</p>
                    </div>
                    <p className="text-gray-600 mb-2">{feedback.comment}</p>
                    <Button variant="ghost" size="sm" className="text-gray-500 hover:text-blue-600 px-0">
                      <ThumbsUp className="w-3 h-3 mr-1" />
                      {feedback.helpful} people found this helpful
                    </Button>
                  </div>
                </motion.div>
              ))}
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
