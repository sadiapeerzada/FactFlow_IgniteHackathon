// Google Fact Check API Integration
// For production, use environment variable
const GOOGLE_FACT_CHECK_API_KEY = 
  (typeof import.meta !== 'undefined' && import.meta.env?.VITE_GOOGLE_FACT_CHECK_API_KEY) || 
  'AIzaSyBBFGAIFewJowiUS-o8gUtyMxSJhZIDGF4';
const FACT_CHECK_API_URL = 'https://factchecktools.googleapis.com/v1alpha1/claims:search';

export interface FactCheckClaim {
  text: string;
  claimant?: string;
  claimDate?: string;
  claimReview?: Array<{
    publisher: {
      name: string;
      site?: string;
    };
    url: string;
    title: string;
    reviewDate?: string;
    textualRating: string;
    languageCode: string;
  }>;
}

export interface FactCheckResponse {
  claims?: FactCheckClaim[];
  nextPageToken?: string;
}

export interface VerificationResult {
  truthIndex: number;
  sourceReliability: number;
  biasScore: number;
  clickbaitScore: number;
  communityScore: number;
  factCheckResults: FactCheckClaim[];
  summary: string;
  status: 'verified' | 'false' | 'uncertain';
  reasoning: string;
}

/**
 * Search for fact-checks using Google Fact Check Tools API
 */
export async function searchFactChecks(query: string): Promise<FactCheckResponse> {
  try {
    const url = `${FACT_CHECK_API_URL}?query=${encodeURIComponent(query)}&key=${GOOGLE_FACT_CHECK_API_KEY}`;
    
    const response = await fetch(url);
    
    if (!response.ok) {
      throw new Error(`API request failed: ${response.status} ${response.statusText}`);
    }
    
    const data: FactCheckResponse = await response.json();
    return data;
  } catch (error) {
    console.error('Fact check API error:', error);
    throw error;
  }
}

/**
 * Extract domain from URL
 */
function extractDomain(url: string): string | null {
  try {
    const urlObj = new URL(url);
    return urlObj.hostname.replace('www.', '');
  } catch {
    return null;
  }
}

/**
 * Check domain credibility based on known sources
 */
function checkDomainCredibility(text: string): { score: number; category: 'high' | 'medium' | 'low' } {
  const highCredibilitySources = [
    'reuters.com', 'bbc.com', 'apnews.com', 'npr.org', 'pbs.org',
    'factcheck.org', 'snopes.com', 'politifact.com', 'nature.com',
    'sciencemag.org', 'nytimes.com', 'washingtonpost.com', 'theguardian.com',
    'cnn.com', 'nbcnews.com', 'cbsnews.com', 'abcnews.go.com'
  ];
  
  const mediumCredibilitySources = [
    'forbes.com', 'bloomberg.com', 'wsj.com', 'time.com', 'newsweek.com',
    'usatoday.com', 'latimes.com', 'chicagotribune.com'
  ];
  
  const textLower = text.toLowerCase();
  
  for (const source of highCredibilitySources) {
    if (textLower.includes(source)) {
      return { score: 90 + Math.random() * 10, category: 'high' };
    }
  }
  
  for (const source of mediumCredibilitySources) {
    if (textLower.includes(source)) {
      return { score: 60 + Math.random() * 20, category: 'medium' };
    }
  }
  
  // Default for unknown sources
  return { score: 40 + Math.random() * 20, category: 'medium' };
}

/**
 * Analyze text for clickbait indicators
 */
function detectClickbait(text: string): number {
  const clickbaitPhrases = [
    'you won\'t believe', 'shocking', 'this one trick', 'doctors hate',
    'what happens next', 'the reason why', 'this is why', 'number',
    'will shock you', 'mind blown', 'incredible', 'unbelievable'
  ];
  
  const textLower = text.toLowerCase();
  let clickbaitScore = 100;
  
  // Check for excessive capitalization
  const capsRatio = (text.match(/[A-Z]/g) || []).length / text.length;
  if (capsRatio > 0.3) clickbaitScore -= 20;
  
  // Check for clickbait phrases
  for (const phrase of clickbaitPhrases) {
    if (textLower.includes(phrase)) {
      clickbaitScore -= 15;
    }
  }
  
  // Check for excessive punctuation
  const exclamationCount = (text.match(/!/g) || []).length;
  if (exclamationCount > 2) clickbaitScore -= 10;
  
  return Math.max(0, clickbaitScore);
}

/**
 * Analyze text for bias indicators
 */
function detectBias(text: string): number {
  const biasedTerms = [
    'always', 'never', 'everyone knows', 'obviously', 'clearly',
    'undeniably', 'without question', 'extreme', 'radical', 'devastating'
  ];
  
  const textLower = text.toLowerCase();
  let biasScore = 100;
  
  for (const term of biasedTerms) {
    if (textLower.includes(term)) {
      biasScore -= 8;
    }
  }
  
  // Check for balanced language
  if (textLower.includes('according to') || textLower.includes('reports suggest')) {
    biasScore += 5;
  }
  
  return Math.max(0, Math.min(100, biasScore));
}

/**
 * Calculate overall truth index from fact-check results
 */
function calculateTruthIndex(
  factCheckResults: FactCheckClaim[],
  sourceReliability: number,
  biasScore: number,
  clickbaitScore: number
): { truthIndex: number; status: 'verified' | 'false' | 'uncertain'; reasoning: string } {
  let totalRating = 0;
  let ratingCount = 0;
  
  // Analyze fact-check ratings
  if (factCheckResults && factCheckResults.length > 0) {
    for (const claim of factCheckResults) {
      if (claim.claimReview) {
        for (const review of claim.claimReview) {
          const rating = review.textualRating.toLowerCase();
          
          // Convert textual ratings to numerical scores
          if (rating.includes('true') || rating.includes('correct') || rating.includes('accurate')) {
            totalRating += 100;
            ratingCount++;
          } else if (rating.includes('mostly true') || rating.includes('mostly correct')) {
            totalRating += 75;
            ratingCount++;
          } else if (rating.includes('mixture') || rating.includes('half true') || rating.includes('unproven')) {
            totalRating += 50;
            ratingCount++;
          } else if (rating.includes('mostly false') || rating.includes('misleading')) {
            totalRating += 25;
            ratingCount++;
          } else if (rating.includes('false') || rating.includes('incorrect') || rating.includes('pants on fire')) {
            totalRating += 0;
            ratingCount++;
          }
        }
      }
    }
  }
  
  // Calculate weighted scores
  const factCheckScore = ratingCount > 0 ? totalRating / ratingCount : 50;
  const communityScore = 70 + Math.random() * 20; // Mock community score for now
  
  // Weighted calculation
  const truthIndex = Math.round(
    factCheckScore * 0.35 +
    sourceReliability * 0.25 +
    biasScore * 0.15 +
    clickbaitScore * 0.10 +
    communityScore * 0.15
  );
  
  // Determine status
  let status: 'verified' | 'false' | 'uncertain';
  if (truthIndex >= 70) {
    status = 'verified';
  } else if (truthIndex < 40) {
    status = 'false';
  } else {
    status = 'uncertain';
  }
  
  // Generate reasoning
  let reasoning = '';
  if (ratingCount > 0) {
    reasoning = `Based on ${ratingCount} fact-check review${ratingCount > 1 ? 's' : ''} from verified sources, `;
    if (status === 'verified') {
      reasoning += 'this claim is supported by credible evidence. Multiple fact-checking organizations have confirmed the accuracy of this information.';
    } else if (status === 'false') {
      reasoning += 'this claim has been debunked by fact-checkers. The information contradicts verified sources and contains significant inaccuracies.';
    } else {
      reasoning += 'this claim shows mixed results. Some elements may be accurate while others require further verification.';
    }
  } else {
    reasoning = 'No specific fact-checks were found for this exact claim. ';
    if (sourceReliability > 70) {
      reasoning += 'However, the source appears to be credible based on domain analysis.';
    } else {
      reasoning += 'We recommend cross-referencing with multiple trusted sources.';
    }
  }
  
  return { truthIndex, status, reasoning };
}

/**
 * Main verification function that combines all analyses
 */
export async function verifyInformation(query: string): Promise<VerificationResult> {
  try {
    // Search for fact-checks
    const factCheckData = await searchFactChecks(query);
    const factCheckResults = factCheckData.claims || [];
    
    // Analyze the input
    const domainData = checkDomainCredibility(query);
    const sourceReliability = domainData.score;
    const biasScore = detectBias(query);
    const clickbaitScore = detectClickbait(query);
    
    // Calculate truth index
    const { truthIndex, status, reasoning } = calculateTruthIndex(
      factCheckResults,
      sourceReliability,
      biasScore,
      clickbaitScore
    );
    
    const communityScore = 70 + Math.random() * 20; // Mock for now
    
    // Generate summary
    let summary = '';
    if (factCheckResults.length > 0) {
      summary = `Found ${factCheckResults.length} fact-check review${factCheckResults.length > 1 ? 's' : ''} for this claim.`;
    } else {
      summary = 'No direct fact-checks found. Analysis based on source credibility and content analysis.';
    }
    
    return {
      truthIndex: Math.round(truthIndex),
      sourceReliability: Math.round(sourceReliability),
      biasScore: Math.round(biasScore),
      clickbaitScore: Math.round(clickbaitScore),
      communityScore: Math.round(communityScore),
      factCheckResults,
      summary,
      status,
      reasoning
    };
  } catch (error) {
    console.error('Verification error:', error);
    
    // Return fallback analysis if API fails
    const sourceReliability = checkDomainCredibility(query).score;
    const biasScore = detectBias(query);
    const clickbaitScore = detectClickbait(query);
    const communityScore = 70;
    
    const truthIndex = Math.round(
      (sourceReliability * 0.4 + biasScore * 0.3 + clickbaitScore * 0.3)
    );
    
    return {
      truthIndex,
      sourceReliability: Math.round(sourceReliability),
      biasScore: Math.round(biasScore),
      clickbaitScore: Math.round(clickbaitScore),
      communityScore,
      factCheckResults: [],
      summary: 'Unable to connect to fact-checking services. Analysis based on content and source evaluation.',
      status: truthIndex >= 60 ? 'uncertain' : 'uncertain',
      reasoning: 'Could not retrieve fact-check data. Scores are based on text analysis and source credibility assessment.'
    };
  }
}
